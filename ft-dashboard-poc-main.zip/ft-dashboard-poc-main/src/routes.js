import { Navigate, useRoutes } from 'react-router-dom';
// layouts
import JsonInput from './pages/JsonInput';
import { DALPlugin } from './sections/dal';
import ParameterForm from './sections/dal/ParameterForm';
import ExcelForm from './pages/ExcelForm';
import ReportsTable from './pages/ReportsTable'

// ----------------------------------------------------------------------

export default function Router() {
  const routes = useRoutes([
    // {
    //   path: '/dashboard',
    //   element: <DashboardLayout />,
    //   children: [
    //     { element: <Navigate to="/dashboard/app" />, index: true },
    //     { path: 'app', element: <DashboardAppPage /> },
    //     { path: 'user', element: <UserPage /> },
    //     { path: 'products', element: <ProductsPage /> },
    //     { path: 'blog', element: <BlogPage /> },
    //   ],
    // },
    {
      path: '/',
      element: <JsonInput />,
    },
    {
      path: 'dal',
      element: <DALPlugin />,
    },
    {
      path: 'excelform',
      element: <ExcelForm />,
    },
    {
      path: 'parameter-subfield',
      element: <ParameterForm />,
    },
    {
      path: 'reportstable',
      element: <ReportsTable />,
    },
    // {
    //   path: 'login',
    //   element: <LoginPage />,
    // },
    {
      path: '*',
      element: <Navigate to="/404" replace />,
    },
  ]);

  return routes;
}
