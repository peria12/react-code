import { format, getTime, formatDistanceToNow } from 'date-fns';

// ----------------------------------------------------------------------

export function fDate(date, newFormat) {
  const fm = newFormat || 'dd MMM yyyy';

  return date ? format(new Date(date), fm) : '';
}

export function fDateTime(date, newFormat) {
  const fm = newFormat || 'dd MMM yyyy p';

  return date ? format(new Date(date), fm) : '';
}

export function fTimestamp(date) {
  return date ? getTime(new Date(date)) : '';
}

export function fToNow(date) {
  return date
    ? formatDistanceToNow(new Date(date), {
        addSuffix: true,
      })
    : '';
}

export function isValid_Date(str) {
  // Regex to check valid
  // DateTime(YYYY-MM-DD)
  const regex = /^([0-9]{4})-((01|02|03|04|05|06|07|08|09|10|11|12|(?:J(anuary|u(ne|ly))|February|Ma(rch|y)|A(pril|ugust)|(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)|(JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)|(September|October|November|December)|(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)|(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)))|(january|february|march|april|may|june|july|august|september|october|november|december))-([0-3][0-9])$/
  
  // if str
  // is empty return false
  if (str == null) {
    return false
  }
  // Return true if the str
  // matched the ReGex
  if (regex.test(str) === true) {
    return true
  } 
  return false
}
export function buildFieldJson(fieldsValue,getTempOthersVal,tempSubFieldData,getTempFilterVal){
  const newObj = [];
  for (const [index, fieldName] of fieldsValue.entries()) {
    newObj.push({ [fieldName.name]: {} });
    for (const item of [...getTempOthersVal,...tempSubFieldData]) {
      if (fieldName.name === item.fieldName) {
        if (item.isArray) {
          const fieldame = fieldName.name;
          const subFieldName = item.subFieldName;
          const nestedKey = item.nestedKey;
          if (!newObj[index][fieldame][subFieldName]) {
            newObj[index][fieldame] = { [item.subFieldName]: [] };
          }
          console.log(fieldame, nestedKey);
          if (fieldame === nestedKey) {
            newObj[index][fieldame][subFieldName].push(item.subFieldValue);
          }
          if (fieldame !== nestedKey && item.subFieldName === "sub_fields") {
            const findnest = newObj[index][fieldame][subFieldName].find(
              (item) => {
                return item[nestedKey];
              }
            );
            if (!findnest) {
              newObj[index][fieldame][subFieldName].push({
                [item.nestedKey]: { sub_fields: [] }
              });
              const findnest = newObj[index][fieldame][subFieldName].find(
                (item) => {
                  return item[nestedKey];
                }
              );
              findnest[item.nestedKey][subFieldName].push(item.subFieldValue);
            }
            if (findnest) {
              findnest[item.nestedKey][subFieldName].push(item.subFieldValue);
            }
          }
        } else {
          console.log(item, "elseiff");
          if (item.fieldName !== item.nestedKey) {
            const testm = newObj[index][item.fieldName][item.subFieldName].find(
              (itm) => itm[item.nestedKey]
            );
            console.log(testm);
            console.log(testm[item.nestedKey], "Dasss");
            Object.assign(testm[item.nestedKey], {[item.subFieldName]:item.subFieldValue});
          } else {
            Object.assign(newObj[index][item.fieldName],{[item.subFieldName]:JSON.parse(item.subFieldValue)})
          }
        }
      }
    }
  }
  if(getTempFilterVal.length !== 0){
    getTempFilterVal.forEach(filteritem=>{
  const findFilterval = newObj.find(
    (item) => item[filteritem.filterObj.selectedField]
  );
  Object.assign(findFilterval[filteritem.filterObj.selectedField],{filters:filteritem.filterObj.filter});
  })
  }
  return newObj
}