import { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Box, FormGroup, InputBase, InputLabel, MenuItem, Paper, Select } from '@mui/material';
import _ from 'lodash';
import { selectedDatesType } from './datesSlice';
import { updateDateInfoJson } from '../../store/jsonReducer'

const DatesTypesFilter = () => {
  const [isDisabled, setIsDisabled] = useState(false);
  const datesType = useSelector(selectedDatesType);
  const [dateInfo, setDateInfo] = useState(null);
  const [interval, setInterval] = useState('');
  const [lookback, setLookBack] = useState('');
  const dispatch = useDispatch();

  useEffect(() => {
    if (datesType !== 'series') {
      setIsDisabled(true);
    } else {
      setIsDisabled(false);
      setDateInfo({ type: 'series' })
    }
  }, [datesType]);
  useEffect(()=>{
  if(dateInfo !== null)
      dispatch(updateDateInfoJson(dateInfo))
  },[dateInfo])

  useEffect(() => {
    if (dateInfo && dateInfo.interval) {
      setInterval(dateInfo.interval);
    }
    if (dateInfo && dateInfo.lookback) {
      setLookBack(dateInfo.lookback);
    }
  }, []);

  const handleFrequencyChange = (event) => {
    setDateInfo((prev) => {
      return { ...prev, freq: { ...prev.freq, unit: event.target.value} };
    });
  };

  const handleFillMissingChange = (event) => {
    setDateInfo((prev) => {
      return { ...prev, fill_Missing: event.target.value };
    });
  };

  const handleAlignChange = (event) => {
    setDateInfo((prev) => {
      return { ...prev, freq: { ...prev.freq, align: event.target.value} };
    });
  };

  const onIntervalChange = (val) => {
    if(val !== ""){
    setDateInfo((prev) => {
      return { ...prev, interval: val };
    });
  }
  };


  const onLookBackChange = (val) => {
    if(val !== ""){
    setDateInfo((prev) => {
      return { ...prev, lookback: val };
    });
  }
  };

  useEffect(() => {
    debouncedOnIntervalChange(interval);
    return () => debouncedOnIntervalChange.cancel();
  }, [interval]);

  useEffect(() => {
    debouncedOnLookBackChange(lookback);
    return () => debouncedOnLookBackChange.cancel();
  }, [lookback]);

  const debouncedOnIntervalChange = _.debounce((e) => onIntervalChange(e), 1500);

  const debouncedOnLookBackChange = _.debounce((e) => onLookBackChange(e), 1500);

  return (
    <Box className="dateFilter" sx={{ flex: 1, py: 1 }}>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="label">Frequency</InputLabel>
        <Select
          sx={{ width: '210px' }}
          labelId="label"
          id="frequency"
          value={dateInfo?.freq?.unit || ''}
          disabled={isDisabled}
          onChange={handleFrequencyChange}
        >
          <MenuItem value="daily">Daily</MenuItem>
          <MenuItem value="weekly">Weekly</MenuItem>
          <MenuItem value="monthly">Monthly</MenuItem>
          <MenuItem value="quarterly">Quarterly</MenuItem>
          <MenuItem value="yearly">Yearly</MenuItem>
        </Select>
      </FormGroup>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="fillMissing">Fill Missing</InputLabel>
        <Select
          sx={{ width: '210px' }}
          onChange={handleFillMissingChange}
          labelId="label"
          id="select"
          value={dateInfo?.fill_Missing || ''}
          disabled={isDisabled}
        >
          <MenuItem value="no">No</MenuItem>
          <MenuItem value="last">Last</MenuItem>
        </Select>
      </FormGroup>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="label">Align</InputLabel>
        <Select
          sx={{ width: '210px' }}
          onChange={handleAlignChange}
          labelId="label"
          id="align"
          value={dateInfo?.freq?.align || ''}
          disabled={isDisabled}
        >
          <MenuItem value="start">Start</MenuItem>
          <MenuItem value="end">End</MenuItem>
        </Select>
      </FormGroup>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="label">Interval</InputLabel>
          <InputBase
            inputProps={{ 'aria-label': 'Add interval' }}
            onChange={(e) => {
              setInterval(e.target.value);
            }}
            value={interval}
            disabled={isDisabled}
          />
      </FormGroup>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="label">Look Back</InputLabel>
        <Paper className='dateInput' component="form">
          <InputBase
            inputProps={{ 'aria-label': 'Add look back' }}
            onChange={(e) => {
              setLookBack(e.target.value);
            }}
            value={lookback}
            disabled={isDisabled}
          />
        </Paper>
      </FormGroup>
    </Box>
  );
};

export default DatesTypesFilter;
