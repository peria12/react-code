import { useEffect } from 'react';
import {useSelector, useDispatch } from 'react-redux';
import { Box, IconButton } from '@mui/material';
// import { getAllFields, removeFields } from './fieldsSlice';
import TableComponent from '../../components/TableComponent';
import Iconify from '../../components/iconify';
import {  selectedDates, removeSelectedDate } from './datesSlice';


const SelectedDatesTable = () => {
  const selectedDatesVal = useSelector(selectedDates);
  const dispatch = useDispatch();
  let formattedDate = []
  function dateFormat(){
    selectedDatesVal.forEach(item=>{
      formattedDate = [...formattedDate,{ id: item, selectedDate: item }]
  })
    return formattedDate
  }
 
  const columns = [
    { field: 'selectedDate', headerName: 'Selected Dates', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 100,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeSelectedDate(params.id));
        };
        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <Box sx={{ flex: 2, marginRight: '10px', height: 350, width: '100%' }}>
      <TableComponent rows={dateFormat()} columns={columns}/>
    </Box>
  );
};

export default SelectedDatesTable;
