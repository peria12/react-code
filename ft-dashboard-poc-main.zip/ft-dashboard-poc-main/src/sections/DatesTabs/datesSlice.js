import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  selectedDatesType: 'snapshots',
  selectedDates: []
};

const datesSlice = createSlice({
  name: 'dates',
  initialState,
  reducers: {
    addSelectedDatesTypes: (state, { payload }) => {
      state.selectedDatesType = payload;
    },
    addSelectedDate: (state, { payload }) => {
      if(Array.isArray(payload)){
          state.selectedDates.push(...payload);
        }else{
          state.selectedDates.push(payload);
        }
    },
    updateSelectedDate: (state, { payload }) => {
      state.selectedDates = payload
    },
    removeSelectedDate: (state, { payload }) => {
      state.selectedDates = state.selectedDates.filter((entity) => entity !== payload);
    },
    resetDatesForm: () => {
      return initialState
    },
  },
});

export default datesSlice.reducer;
export const { addSelectedDatesTypes, addSelectedDate, updateSelectedDate, removeSelectedDate, resetDatesForm } = datesSlice.actions;

// export data
export const selectedDatesType = (state) => state.dates?.selectedDatesType;
export const selectedDates = (state) => state.dates?.selectedDates;