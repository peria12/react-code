import { Box, FormControl, FormGroup } from '@mui/material';
import Button from '@mui/material/Button';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import useLocalStorage from '../../hooks/useLocalStorage';
import { updateDateJson } from '../../store/jsonReducer'
import DatesTypes from './DatesTypes';
import DatesTypesFilter from './DatesTypesFilter';
import SelectedDatesTable from './SelectedDatesTable';
import { addSelectedDate, selectedDates, updateSelectedDate } from './datesSlice';
import { isValid_Date } from '../../utils/formatTime';

const DatesContainer = () => {
  const dispatch = useDispatch();
  const [jsonCreator, setJsonCreator] = useLocalStorage('createdJson', '');
  const [selectedDate, setSelectedDate] = useState(null);
  const [error, setError] = useState(false);
  const selectedDatesVal = useSelector(selectedDates);
  const [multipleDates, setMultipleDates] = useState('');
  const isFromDalPlugin = window.navigator.userAgent.toLowerCase() === 'dalplugin'
  const handleAddDate = () => {
    const formatDate = new Date(selectedDate.$d.getTime() - selectedDate.$d.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 10);
    if (!selectedDatesVal.includes(formatDate)) {
      setError(false);
      dispatch(addSelectedDate(formatDate));
    } else {
      setError(true);
    }
  };

  useEffect(() => {
    if (jsonCreator?.dates) {
      dispatch(updateSelectedDate(jsonCreator.dates));
    }
  }, []);
  useEffect(() => {
    if(selectedDatesVal.length !== 0)
    dispatch(updateDateJson(selectedDatesVal))
  }, [selectedDatesVal]);
  const handleOnChange = (e) => {
    setMultipleDates(e.target.value);
  };

  const postSelect = () => {
    if (isFromDalPlugin) {
      window.chrome.webview.postMessage(JSON.stringify({message:'SelectFromExcel',data:null,calledfrom:"dates"}));
    }
    else {
      const datesarray = multipleDates.split(',');
      const isDatesValid = datesarray.filter((item) => !isValid_Date(item));
      const isUnique = datesarray.filter((item) => selectedDatesVal.includes(item));
      if(isDatesValid.length === 0 && isUnique.length === 0) {
      dispatch(addSelectedDate(datesarray));
      setMultipleDates("")
    }
    else{
      setError(true);
    }
    }
  }
  if (isFromDalPlugin) {
    window.chrome.webview.addEventListener('message', event => {
      const val = event.data
      if (val.message === "SelectFromExcel" && val.calledfrom==="entities") {
        setMultipleDates(val.data)
        const datesarray = val.data.split(',');
        const isDatesValid = datesarray.filter((item) => !isValid_Date(item));
        const isUnique = datesarray.filter((item) => selectedDatesVal.includes(item));
        if(isDatesValid.length === 0 && isUnique.length === 0) {
        dispatch(addSelectedDate(datesarray));
        setMultipleDates("")
      }
      }
    });
  }
  return (
    <CardContent>
        <div style={{ display: 'flex', gap:'20px'}}>
            <Typography sx={{ color: '#8E8D8D', fontSize: '15px', marginRight: '16px' }}>
              Date
            </Typography>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DemoContainer components={['DatePicker']}>
                <DatePicker
                  disableFuture
                  format="YYYY-MM-DD"
                  value={selectedDate}
                  onChange={(newDateValue) => {
                    setSelectedDate(newDateValue);
                  }}
                  sx={{ width: '150px', overflow: 'hidden' }}
                />
              </DemoContainer>
            </LocalizationProvider>
            <Button variant="outlined" color="secondary" onClick={handleAddDate}>
              Add Dates
            </Button>
            </div>
          {error && <small className="error"> Date Already Added</small>}
          <Box
            sx={{
              borderBottom: 1,
              borderColor: 'divider',
              display: 'flex',
              paddingBottom: '12px',
            }}
            className="datesScreen"
          >
        <div className='multidate'>
        <Typography sx={{ color: '#8E8D8D', width: '60px', fontSize: '15px'}}>
          Multiple Dates
        </Typography>
        <textarea id="datesScreenexcelvalues" value={multipleDates} onChange={handleOnChange} />
        <Button className="selectValueBtn" variant="outlined" color="secondary" onClick={postSelect}>
          {isFromDalPlugin ? "Select from Excel" : "submit"}
        </Button>
        </div>
        <FormGroup sx={{ flexDirection: 'row' }}>
        <DatesTypes />
        </FormGroup>
        </Box>

      <Box sx={{ display: 'flex' }}>
        <SelectedDatesTable />
        <DatesTypesFilter />
      </Box>
    </CardContent>
  );
};

export default DatesContainer;
