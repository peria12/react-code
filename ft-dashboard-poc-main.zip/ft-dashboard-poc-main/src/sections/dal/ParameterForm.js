import { Button, Container } from '@mui/material';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Step from '@mui/material/Step';
import { useNavigate } from 'react-router-dom';
import StepLabel from '@mui/material/StepLabel';
import Stepper from '@mui/material/Stepper';
import { styled } from '@mui/material/styles';
import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import AuthenticationMessage from '../../components/authentication-message';
import Header from '../../layouts/dashboard/header';
import ParametersContainer from '../ParameterTabs/ParametersContainer';

const steps = ['Fields', 'Entities', 'Dates'];

const StyledRoot = styled('div')(({ theme }) => ({
  [theme.breakpoints.up('md')]: {
    display: 'flex',
  },
}));

const StyledContent = styled('div')(() => ({
  width: '100%',
  margin: 'auto',
  minHeight: '100vh',
  display: 'flex',
  justifyContent: 'center',
  flexDirection: 'column',
  // padding: theme.spacing(12, 0),
}));

const ParameterForm = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const handleCancel = () => {
    navigate('/dal');
  };
  const handleSaveParameters = () => {
    navigate('/dal');
  };
  return (
    <>
      <Helmet>
        <title> Dashboard | Parameters Subfield </title>
      </Helmet>

      <StyledRoot>
        <Header onOpenNav={() => setOpen(true)} />
        <Container maxWidth="lg">
          <StyledContent>
            <Box sx={{ width: '100%', marginTop: '110px' }}>
              <Stepper alternativeLabel>
                {steps.map((label, index) => {
                  const stepProps = {};
                  const labelProps = {};

                  return (
                    <Step key={label} {...stepProps}>
                      <StepLabel {...labelProps}>{label}</StepLabel>
                    </Step>
                  );
                })}
              </Stepper>
              <>
                <Card sx={{ width: '100%', height: 475, padding: '16px', marginTop: '20px' }}>
                  <ParametersContainer />
                </Card>
                <Box sx={{ display: 'flex', flexWrap: 'nowrap', justifyContent: 'space-between', pt: 2 }}>
                  <Button onClick={handleCancel} color="tertiary" variant="outlined">
                    Cancel
                  </Button>
                  <Button color="primary" variant="contained" onClick={handleSaveParameters}>
                    Save Parameters
                  </Button>
                </Box>
              </>
            </Box>
          </StyledContent>
          <AuthenticationMessage />
        </Container>
      </StyledRoot>
    </>
  );
};

export default ParameterForm;
