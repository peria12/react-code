import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Stepper from '@mui/material/Stepper';
import Typography from '@mui/material/Typography';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import AuthenticationMessage from '../../components/authentication-message';
import DatesContainer from '../DatesTabs';
import EntitiesContainer from '../EntitiesTabs';
import FieldsContainer from '../FieldsTab';
import useLocalStorage from "../../hooks/useLocalStorage";
import { getTempEntityData,resetEntityData, saveEntityData, updateSearchEntity, getSavedEntityData, getIdDate, getIdType } from '../EntitiesTabs/entitiesSlice';
import { getJsonValue,updateEntitiesJson,updateIdDateJson,updateIdTypeJson } from '../../store/jsonReducer';

const steps = ['Fields', 'Entities', 'Dates'];

// function renderRow() {
//   <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
//     {[1, 2, 3].map((value) => (
//       <ListItem
//         key={value}
//         secondaryAction={<Iconify aria-label="list" icon={'gridicons:menus'} sx={{ color: 'pink' }} />}
//       >
//         <ListItemText primary={`Line item ${value}`} />
//       </ListItem>
//     ))}
//   </List>;
// }

export default function DALPlugin() {
  const navigate = useNavigate();

  const [activeStep, setActiveStep] = useState(0);
  const tempEntityData = useSelector(getTempEntityData);
  const savedEntityData = useSelector(getSavedEntityData);
  const tempIdDate = useSelector(getIdDate);
  const tempIdType = useSelector(getIdType);

  const dispatch = useDispatch();
  
  const saveEntitiesData = () =>{
      dispatch(saveEntityData(tempEntityData))
      if(tempEntityData.length !== 0)
      dispatch(updateEntitiesJson(tempEntityData))
      if(tempIdDate !== '')
      dispatch(updateIdDateJson(tempIdDate))
      if(tempIdType !== '')
      dispatch(updateIdTypeJson(tempIdType))
  }
  const resetEntitiesData = () =>{
    dispatch(resetEntityData())
    dispatch(updateSearchEntity(savedEntityData))
  }
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    if(steps[activeStep] === "Entities"){
      saveEntitiesData()
    }
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleCancel = () => {
    navigate('/');
      if(steps[activeStep] === "Entities"){
        resetEntitiesData()
      }
  };


  return (
    <Box sx={{ width: '100%', marginTop: '80px' }}>
      <Stepper activeStep={activeStep} alternativeLabel>
        {steps.map((label, index) => {
          const stepProps = {};
          const labelProps = {};

          return (
            <Step key={label} {...stepProps}>
              <StepLabel {...labelProps}>{label}</StepLabel>
            </Step>
          );
        })}
      </Stepper>
      {activeStep === steps.length ? (
        <>
          <Card sx={{ minWidth: 275, minHeight: 300, margin: 2 }}>
            <CardContent>
              <Typography variant="body2">Fetching data...</Typography>
              <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
                <Box sx={{ flex: '1 1 auto' }} />
                {/* <Button onClick={handleReset}>Reset</Button> */}
              </Box>
            </CardContent>
          </Card>
        </>
      ) : (
        <>
          <Typography component="div" sx={{ my: 2 }}>
            <Card sx={{ width: '100%', minHeight: 420 }}>
              {activeStep === 0 && <FieldsContainer />}
              {activeStep === 1 && <EntitiesContainer />}
              {activeStep === 2 && <DatesContainer />}
            </Card>
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
            <Button
              color="tertiary"
              variant="outlined"
              //  disabled={activeStep === 0}
              onClick={handleCancel}
            >
              Cancel
            </Button>
            <Box sx={{ flex: '1 1 auto' }} />
            {activeStep !==0 && (
              <Button color="secondary" variant="outlined" onClick={handleBack} sx={{ mr: 1 }}>
                Previous
              </Button>
            )}
            {activeStep === steps.length - 1 ?
            <Button variant="contained" color="primary">
               Fetch Data
            </Button>
                    :
            <Button variant="contained" color="primary" onClick={handleNext}>
              Next
            </Button>
            }
          </Box>
          <AuthenticationMessage />
        </>
      )}
    </Box>
  );
}
