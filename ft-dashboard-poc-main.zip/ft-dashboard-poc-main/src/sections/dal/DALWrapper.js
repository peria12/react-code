import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
// @mui
import { styled } from '@mui/material/styles';
import { Link, Container, Typography, Divider, Stack, Button } from '@mui/material';
// hooks
import useResponsive from '../../hooks/useResponsive';
// components
import Logo from '../../components/logo';
import Iconify from '../../components/iconify';
// sections
import DALPlugin from './DALPlugin';
import Header from '../../layouts/dashboard/header';

// ----------------------------------------------------------------------

const StyledRoot = styled('div')(({ theme }) => ({
  [theme.breakpoints.up('md')]: {
    display: 'flex',
  },
}));

const StyledContent = styled('div')(({ theme }) => ({
  width: '100%',
  marginTop: '50px',
  // minHeight: '100vh',
  display: 'flex',
  justifyContent: 'center',
  flexDirection: 'column',
  // padding: theme.spacing(12, 0),
}));

// ----------------------------------------------------------------------

export default function LoginPage() {
  const mdUp = useResponsive('up', 'md');
  const [open, setOpen] = useState(false);

  return (
    <>
      <Helmet>
        <title> Dashboard | DAL Plugin </title>
      </Helmet>

      <StyledRoot>
        <Header onOpenNav={() => setOpen(true)} />
        {/* <Logo
          sx={{
            position: 'fixed',
            top: { xs: 16, sm: 24, md: 40 },
            left: { xs: 16, sm: 24, md: 40 },
          }}
        /> */}

        <Container maxWidth="lg">
          <StyledContent>
            <DALPlugin />
          </StyledContent>
        </Container>
      </StyledRoot>
    </>
  );
}
