import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IconButton, FormGroup } from '@mui/material';
import Button from '@mui/material/Button';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
import Iconify from '../../components/iconify';
import { addSearchEntity, getTempEntityData, removeKeyValuePairs } from './entitiesSlice';
import TableComponent from '../../components/TableComponent';
import IDDateComponent from './IDDateComponent'

const inlineFormStyles = {
  display: 'flex',
  gap: '8px',
  justifyContent: 'space-between',
};

const KeyValuePairsTab = () => {
  const dispatch = useDispatch();
  const [snackBaropen, setSnackBaropen] = useState(false);
  const [messageInfo, setMessageInfo] = useState();

  const tempEntityData = useSelector(getTempEntityData);


  const initialState = {
    key: '',
    value: '',
  };
  const [keyValue, setKeyValue] = useState(initialState);

  const update = (event) => {
    const { name, value } = event.target;
    setKeyValue((prev) => {
      return { ...prev, [name]: value };
    });
  };
  const handleClose = (e, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackBaropen(false);
  };
  const submitHandler = () => {
    setKeyValue(keyValue);
    const isPresent = tempEntityData.filter((item) => {
      let keep = false;
      if (typeof item === "object") {
        const val = Object.entries(item);
        keep = val[0][0] === keyValue.key 
      }
      return keep;
    })
    console.log(isPresent,"sdadasd")
    if( keyValue.key  === "" || keyValue.value === ""){
      setSnackBaropen(true)
      setMessageInfo({ message: `Key Value should not be empty`, severity: 'warning' })
    }
    else if(isPresent.length !== 0){
      setSnackBaropen(true)
      setMessageInfo({ message: `Key already exist`, severity: 'warning' })
    }
    else{
    setSnackBaropen(false)
    dispatch(addSearchEntity({ [keyValue.key]: keyValue.value }));
    setKeyValue(initialState)
  }
  };
  const filteredObjData = []
  function entityDataObjFormat(){
    tempEntityData.forEach(item=>{
      if(typeof item === 'object'){
      const Obj = Object.entries(item)
      filteredObjData.push({
        id: Math.random() * 100,
        key: Obj[0][0],
        value: Obj[0][1],
      })
    }
    })
    return filteredObjData
  }
  const columns = [
    { field: 'key', headerName: 'Key', flex: 1, editable: false, sortable: false },
    { field: 'value', headerName: 'Values', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeKeyValuePairs(params.row));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];
  return (
    <>
      <div style={inlineFormStyles}>
        <FormGroup sx={{ flexDirection: 'row' }}>
          <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
            Key
          </Typography>
          <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 200 }}>
            <InputBase sx={{ ml: 1, flex: 1 }} name="key" value={keyValue.key} onChange={update} inputProps={{ 'aria-label': 'Add key' }} />
          </Paper>
          <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
            Value
          </Typography>
          <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 250 }}>
            <InputBase
              sx={{ ml: 1, flex: 1 }}
              name="value"
              onChange={update}
              value={keyValue.value}
              inputProps={{ 'aria-label': 'Add value' }}
            />
          </Paper>
          <Button variant="outlined" color="secondary" type="submit" onClick={submitHandler}>
            Add Key & Value
          </Button>
        </FormGroup>
        <FormGroup sx={{ flexDirection: 'row' }}>
        <IDDateComponent />
        </FormGroup>
        </div>
        <TableComponent rows={entityDataObjFormat()} columns={columns}/>
        <Snackbar open={snackBaropen} autoHideDuration={1000} onClose={handleClose}>
        <Alert variant="filled" severity={messageInfo?.severity} sx={{ width: '100%' }}>
          {messageInfo?.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default KeyValuePairsTab;
