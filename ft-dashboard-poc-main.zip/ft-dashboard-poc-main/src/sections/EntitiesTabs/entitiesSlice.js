import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  actualEntitiesData: [], // addActualEntitiesData => Entities list from the API
  selectedEntityData: [],
  savedEntityData: [],
  keyValuePairs: [],
  entitiesKeyList: [],
  idDate:'',
  idType:''
};

const entitiesSlice = createSlice({
  name: 'entities',
  initialState,
  reducers: {
    addActualEntitiesData: (state, { payload }) => {
      state.actualEntitiesData = payload;
    },
    addSearchEntity: (state, { payload }) => {
      if(Array.isArray(payload)){
      state.selectedEntityData.push(...payload);
      }else{
      state.selectedEntityData.push(payload)
      }
      console.log('Add Payload', payload);
    },
    saveEntityData: (state, { payload }) => {
      state.savedEntityData = payload
    },
    updateSearchEntity: (state, { payload }) => {
      state.selectedEntityData = payload
    },
    removeSearchEntity: (state, { payload }) => {
      state.selectedEntityData = state.selectedEntityData.filter((entity) => entity !== payload);
    },
    resetEntityData: (state) => {
      state.selectedEntityData = []
    },
    addEntitiesKeyList: (state, { payload }) => {
      state.entitiesKeyList = payload;
    },
    addIdDate: (state, { payload }) => {
      state.idDate = payload;
    },
    addIdType: (state, { payload }) => {
      state.idType = payload;
    },
    removeKeyValuePairs: (state, { payload }) => {
      state.selectedEntityData = state.selectedEntityData.filter((item) => {
        let keep = true;
        if (typeof item === "object") {
          const val = Object.entries(item);
          keep = val[0][0] !== payload.key || val[0][1] !== payload.value;
        }
        return keep;
      })
    },
    resetEntitiesForm: () => initialState,
  },
});

// export actions
export default entitiesSlice.reducer;
export const {
  addActualEntitiesData,
  addSearchEntity,
  updateSearchEntity,
  removeSearchEntity,
  resetEntityData,
  saveEntityData,
  addEntitiesKeyList,
  removeKeyValuePairs,
  resetEntitiesForm,
  addIdDate,
  addIdType
} = entitiesSlice.actions;

export const getApiEntityData = (state) => state.entities?.actualEntitiesData;
export const getTempEntityData = (state) => state.entities?.selectedEntityData;
export const getSavedEntityData = (state) => state.entities?.savedEntityData;
export const getIdDate = (state) => state.entities?.idDate;
export const getIdType = (state) => state.entities?.idType;


