import { useDispatch } from 'react-redux';
import { CardContent } from '@mui/material';
import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import KeyValuePairsTab from './KeyValuePairsTab';
import SearchTab from './SearchTab';
import SelectFromExcelTab from './SelectFromExcelTab';
import entityData from '../../_mock/entitiesResponse.json';
import { addActualEntitiesData, addEntitiesKeyList } from './entitiesSlice';

function TabPanel(props) {
  const { children, value, index, ...other } = props;
 
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ padding: '24px 0' }}>
          <Box>{children}</Box>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

const EntitiesContainer = () => {
  const [value, setValue] = useState(0);
  const dispatch = useDispatch();
  const isFromDalPlugin = window.navigator.userAgent.toLowerCase() === "dalplugin"

  const handleChange = (event, newValue) => {
    console.log(newValue,"newValue")
    setValue(newValue);
  };

  // this is temp code until I get API access
  const { entities: entitiesList } = entityData;
  const data = entitiesList.map(({ entity_id: entityID, entity_name: entityName }) => ({
    id: entityID,
    entity_id: entityID,
    entity_name: entityName,
  }));
  dispatch(addActualEntitiesData(data));

  const data2 = Object.keys(Object.assign({}, ...entitiesList));
  dispatch(addEntitiesKeyList(data2));

  return (
    <CardContent>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs
          TabIndicatorProps={{ style: { background: 'none' } }}
          value={value}
          onChange={handleChange}
          aria-label="entities tab"
        >
          <Tab label="Search" {...a11yProps(0)} />
          <Tab label="Key Value Pairs" {...a11yProps(1)} />
          <Tab label={isFromDalPlugin ? "Select from Excel": "Select Values"} {...a11yProps(2)} />
        </Tabs>
      </Box>
      <TabPanel value={value} index={0}>
        <SearchTab />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <KeyValuePairsTab />
      </TabPanel>
      <TabPanel value={value} index={2}>
        <SelectFromExcelTab />
      </TabPanel>
    </CardContent>
  );
};

export default EntitiesContainer;
