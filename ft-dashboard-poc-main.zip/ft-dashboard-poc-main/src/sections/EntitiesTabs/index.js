import EntitiesContainer from './EntitiesContainer';

export default EntitiesContainer;
