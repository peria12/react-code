import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, IconButton } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import Alert from '@mui/material/Alert';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Snackbar from '@mui/material/Snackbar';
import TableNoData from '../../components/TableNoData';
import TableComponent from '../../components/TableComponent';
import Iconify from '../../components/iconify';
import { addSearchEntity, removeSearchEntity, getApiEntityData, getTempEntityData } from './entitiesSlice';


const SearchTab = () => {
  const [snackBaropen, setSnackBaropen] = useState(false);
  const [messageInfo, setMessageInfo] = useState();
  const [searchValue, setSearchValue] = useState('')
  const [filterData, setFilterData] = useState([])

  const apiEntityData = useSelector(getApiEntityData);
  const tempEntityData = useSelector(getTempEntityData);

  const dispatch = useDispatch();
  
  useEffect(() => {
    const filteredEntities  = apiEntityData.filter((user) => {
      return searchValue.trim().length === 0 ? setFilterData([]) : user.entity_name.toLowerCase().includes(searchValue) || user.entity_id.toString().includes(searchValue)
    });
    setFilterData(filteredEntities)
  }, [searchValue])

  const handleOnRowDoubleClick = (rowData, id) => {
    if (!tempEntityData.includes(id)) {
      dispatch(addSearchEntity(id));
      setSnackBaropen(true)
      setMessageInfo({ message: `Entity ${id} Added`, severity: 'success' })
      EntityDataFormat()
    } else {
      setMessageInfo({ message: `Entity Already Exists`, severity: 'error' })
    }
  };
  const handleClose = (e, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackBaropen(false);
  };
  const handleSearchFieldOnChange = (e) => {
    setSearchValue(e.target.value)

  };
  let filteredData = []
  function EntityDataFormat() {
    tempEntityData.forEach(item => {
      if (typeof item !== 'object')
        filteredData = [...filteredData, { id: item, rowID: item }]
    })
    return filteredData
  }
  const columns = [
    { field: 'entity_id', headerName: 'Entities', width: 250, editable: false, sortable: false },
    { field: 'entity_name', headerName: 'Description', flex: 1, editable: false, sortable: false },
  ];
  const selectedEntityColumns = [
    { field: 'rowID', headerName: 'Entities', flex: 1, editable: false, sortable: false },
    { field: 'entity_name', headerName: 'Values', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeSearchEntity(params.id));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <>
      <Box sx={{ padding: 0, height: 350, width: '100%' }}>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 300 }}>
          <InputBase
            sx={{ ml: 1, flex: 2, }}
            placeholder="Search Entities"
            inputProps={{ 'aria-label': 'Search Entities' }}
            value={searchValue}
            onChange={handleSearchFieldOnChange}
          />
          <Iconify className="inputSearchIcon" icon={'iconamoon:search-bold'} />
        </Paper>
        <DataGrid
          rowHeight={48}
          rows={filterData}
          columns={columns}
          className={filterData.length === 0 && "hideFooterPagination hideNoData"}
          initialState={{
            pagination: {
              paginationModel: {
                pageSize: 5,
              },
            },
          }}
          sx={{
            '&.MuiDataGrid-root .MuiDataGrid-columnHeader:focus, &.MuiDataGrid-root .MuiDataGrid-cell:focus-within': {
              outline: 'none',
            },
            overflowX: 'hidden',
          }}
          pageSizeOptions={[5]}
          disableRowSelectionOnClick
          disableColumnMenu
          slots={{
            noRowsOverlay: TableNoData,
          }}
          onRowDoubleClick={(param) => handleOnRowDoubleClick(param.row, param.id)}
        />
      </Box>
      <Box sx={{ padding: '24px 0px', height: 250, width: '100%' }}>
        <TableComponent rows={EntityDataFormat()} columns={selectedEntityColumns} tableHeight={250} />
      </Box>

      <Snackbar open={snackBaropen} autoHideDuration={100000} onClose={handleClose}>
        <Alert variant="filled" onClose={handleClose} severity={messageInfo?.severity} sx={{ width: '100%' }}>
          {messageInfo?.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default SearchTab;
