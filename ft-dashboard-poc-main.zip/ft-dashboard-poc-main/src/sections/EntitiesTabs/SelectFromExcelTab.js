import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import _ from "lodash";
import { Box, IconButton } from '@mui/material';
import Button from '@mui/material/Button';
import CardContent from '@mui/material/CardContent';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import IDDateComponent from './IDDateComponent';
import Iconify from '../../components/iconify';
import { addIdType, getIdType, getTempEntityData, addSearchEntity, removeSearchEntity } from './entitiesSlice';
import TableComponent from '../../components/TableComponent';

const inlineFormStyles = {
  display: 'flex',
  gap: '8px',
};

const SelectFromExcelTab = () => {
  const isFromDalPlugin = window.navigator.userAgent.toLowerCase() === "dalplugin"
  const [selectedexcelVal, setSelectedExcelVal] = useState('');
  const tempIdType = useSelector(getIdType);
  const [idType, setIdType] = useState(tempIdType)

  const tempEntityData = useSelector(getTempEntityData);

  const dispatch = useDispatch();

  const delayInputVal = _.debounce((value) => dispatch(addIdType(value)), 1500);
  const handleIDTypeOnChange = (e) => {
    setIdType(e.target.value)
  }

  useEffect(() => {
    delayInputVal(idType);
    return () => delayInputVal.cancel();
  }, [idType]);

  const postSelect = () => {
    if (isFromDalPlugin) {
      window.chrome.webview.postMessage(JSON.stringify({message:'SelectFromExcel',data:null,calledfrom:"entities"}));
    }
    else {
      const array = selectedexcelVal.split(',');
      dispatch(addSearchEntity(array));
    }
  }
  if (isFromDalPlugin) {
    window.chrome.webview.addEventListener('message', event => {
      const val = event.data
      if (val.message === "SelectFromExcel" && val.calledfrom==="entities") {
        setSelectedExcelVal(val.data)
        const array = val.data.split(',');
        dispatch(addSearchEntity(array));
      }
    });
  }
  const handleOnChange = (e) => {
    setSelectedExcelVal(e.target.value);
  };

  let filteredData = []
  function EntityDataFormat() {
    tempEntityData.forEach(item => {
      if (typeof item !== 'object')
        filteredData = [...filteredData, { id: item, rowID: item }]
    })
    return filteredData
  }
  const selectedEntityColumns = [
    { field: 'rowID', headerName: 'Entities', flex: 1, editable: false, sortable: false },
    { field: 'entity_name', headerName: 'Values', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeSearchEntity(params.id));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <>
      <CardContent sx={{ padding: '0px' }}>
        <div style={{ display: 'flex', gap: '13px'}}>
          <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
            ID Type
          </Typography>
          <Paper component="form" sx={{ display: 'flex', marginRight: '16px', alignItems: 'center', width: 270 }}>
            <InputBase
              sx={{ ml: 1, flex: 2, }}
              placeholder="ID Type"
              value={idType}
              onChange={handleIDTypeOnChange}
            />
          </Paper>
          <IDDateComponent />
          {/* <Button variant="outlined" color="secondary" startIcon={<Iconify icon={'file-icons:microsoft-excel'} />}>
            Select
          </Button> */}
        </div>
      </CardContent>
      <div style={{ display: 'flex', gap: '8px'}}>
        <Typography sx={{ color: '#8E8D8D', width: '60px', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
          Add Entities
        </Typography>
        <textarea id="selectedexcelvalues" value={selectedexcelVal} onChange={handleOnChange} />
        <Button className="selectValueBtn" variant="outlined" color="secondary" onClick={postSelect}>
          {isFromDalPlugin ? "Select from Excel" : "submit"}
        </Button>
      </div>
      <Box sx={{ padding: 0, height: 350, width: '100%' }}>
        <TableComponent rows={EntityDataFormat()} columns={selectedEntityColumns} />
      </Box>
    </>
  );
};

export default SelectFromExcelTab;
