
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Typography from '@mui/material/Typography';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from "dayjs";
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { addIdDate, getIdDate } from './entitiesSlice';


const IDDateComponent = () => {
    const tempIdDate = useSelector(getIdDate);
    const dispatch = useDispatch();
    const dateHandler = (newDateValue) =>{
        console.log(newDateValue)
        const formatDate = newDateValue && new Date(newDateValue.$d.getTime() - newDateValue.$d.getTimezoneOffset() * 60000)
        .toISOString()
        .slice(0, 10);
        dispatch(addIdDate(formatDate))
    }
    return (<>
          <Typography sx={{ color: '#8E8D8D', fontSize: '15px', marginRight: '16px', display: 'flex', alignItems: 'center' }}>ID Date</Typography>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer components={['DatePicker']}>
              <DatePicker
               slotProps={{ 
                actionBar: { actions: ['clear'] },
              }}
                disableFuture
                format="YYYY-MM-DD"
                value={dayjs(tempIdDate)}
                onChange={dateHandler}
                sx={{ width: '150px', overflow: 'hidden' }}
              />
            </DemoContainer>
          </LocalizationProvider>
    </>)
}
export default IDDateComponent