import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import AddFieldComponent from '../../components/AddFieldComponent';
import TableComponent from '../../components/TableComponent';
import Iconify from '../../components/iconify';
import CustomModal from '../../components/CustomModal';
import ParametersContainer from './ParametersContainer';
import { addNestedField,getNestedFields } from '../FieldsTab/fieldsSlice';

const NestedSubFieldContainer = ({ handleNestedSubFieldModal, selectedField }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [error, setError] = useState(false);
  const [searchFieldValue, setSearchFieldValue] = useState('');
  const [selectedNestedField, setSelectedNestedField] = useState('');
console.log(selectedNestedField,"Asd")
  const dispatch = useDispatch();
  const rows = useSelector(getNestedFields);

 
  const handleSearchFieldOnChange = (event) => {
    setSearchFieldValue(event.target.value);
  };

  const onSearchField = (searchTerm) => {
    setSearchFieldValue(searchTerm);
  };
  const handleSubFieldModal = (value) => {
    setIsOpen(value)
  }
 
  const handleAddField = () => {
    const isPresent = rows.some((item) => item.name === searchFieldValue);
    if (!isPresent && searchFieldValue !== '') {
      setError(false);
      dispatch(
        addNestedField({
          id: searchFieldValue,
          name: searchFieldValue,
        })
      );
      setSearchFieldValue("")
    } else {
      setError(true);
    }
  };
  const columns = [
    { field: 'name', headerName: 'Fields', flex: 0.5, editable: false, sortable: false },
    {
      field: 'parameters',
      headerName: 'Parameters',
      flex: 1,
      editable: false,
      sortable: false,
      renderCell: (params) => {
        const handleOpenParameters = () => {
          setSelectedNestedField(params.id)
          setIsOpen(true);
        };
        return (
          <button
            style={{
              backgroundColor: '#E2F3F4',
              color: '#000000CC',
              cursor: 'pointer',
              textAlign: 'start',
              border: 'none',
              width: '100%',
              height: '45px',
            }}
            onClick={handleOpenParameters}
          >
            Parameters
          </button>
        );
      },
    },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation(); // don't select this row after clicking
          // <ConfirmationDialog fieldName={fieldName} rowID={params.id} />;
          // dispatch(removeFields(params.id));
          // console.log(params.id);
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <>
      <AddFieldComponent 
      fieldName={[]} 
      handleSearchFieldOnChange={handleSearchFieldOnChange}
      onSearchField={onSearchField}
      searchFieldValue={searchFieldValue}
      handleAddField={handleAddField}
      error={error}
      tableComponent={<TableComponent rows={rows} columns={columns} />} />
      <div className="flex-container">
        <Button color="tertiary" variant="outlined" onClick={() => handleNestedSubFieldModal(false)}>
          Cancel
        </Button>
        <Button variant="contained" color="primary" onClick={() => handleAddField()}>
          Next
        </Button>
      </div>
      <CustomModal
        showModal={isOpen}
        bodyComponent={<ParametersContainer selectedField={selectedField} selectedNestedField={selectedNestedField}  handleSubFieldModal={handleSubFieldModal} />}
        className={'Modal'}
        closeModal={()=>{setIsOpen(false)}}
      />
    </>
  );
};

export default NestedSubFieldContainer;
