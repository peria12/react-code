import Button from '@mui/material/Button';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import { IconButton } from '@mui/material';
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Iconify from '../../components/iconify';
import { addOthers, removeOthers, getTempOthers, getSavedOthers} from '../FieldsTab/fieldsSlice';
import TableComponent from '../../components/TableComponent';

const inlineFormStyles = {
  display: 'flex',
  gap: '8px',
};

const OthersParameters = ({ parameterID }) => {
  const dispatch = useDispatch()
  const getTempOthersVal = useSelector(getTempOthers)
  const getSavedOther = useSelector(getSavedOthers)

  const initialState = {
    key: '',
    value: '',
  };
  const [keyValue, setKeyValue] = useState(initialState);

  const update = (event) => {
    const { name, value } = event.target;
    setKeyValue((prev) => {
      return { ...prev, [name]: value };
    });
  };

  const submitHandler = (event) => {
    event.preventDefault();
    setKeyValue(keyValue);
    dispatch(addOthers({
      subFieldValue: keyValue.value,
      subFieldName: keyValue.key,
      fieldName: parameterID,
      nestedKey: parameterID,
      subFieldObjKey: keyValue.key
  }));
  };

  const columns = [
    { field: 'id', headerName: 'Key', flex: 1, editable: false, sortable: false },
    { field: 'value', headerName: 'Values', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeOthers(params.id));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  let formatOthers = []
  function formatOthersData(){
    [...getTempOthersVal,...getSavedOther].forEach(item=>{
      formatOthers = [...formatOthers,{id:item.subFieldName,value:item.subFieldValue}]
  })
    return formatOthers
  }

  return (
    <>
      <form style={inlineFormStyles} onSubmit={submitHandler}>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>Key</Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 200 }}>
          <InputBase sx={{ ml: 1, flex: 1 }} name="key" onChange={update} inputProps={{ 'aria-label': 'Add key' }} />
        </Paper>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
          Value
        </Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 250 }}>
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            name="value"
            onChange={update}
            inputProps={{ 'aria-label': 'Add value' }}
          />
        </Paper>
        <Button color="secondary" variant="outlined" type="submit">
          Add Key Value
        </Button>
      </form>

      <TableComponent rows={formatOthersData()} columns={columns}/>
    </>
  );
};

export default OthersParameters;
