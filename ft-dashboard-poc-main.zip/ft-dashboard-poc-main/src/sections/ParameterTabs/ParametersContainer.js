import { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import PropTypes from 'prop-types';
import Button from '@mui/material/Button';
import { useDispatch, useSelector } from 'react-redux';

import FiltersParameter from './FiltersParameter';
import OthersParameters from './OthersParameters';
import SubFieldParameter from './SubFieldParameter';
import CustomModal from '../../components/CustomModal';
import NestedSubFieldContainer from './NestedSubFieldContainer';

import { getAllFields, getTempSubFieldData, getTempFilters, resetFilters, saveFilters, getSavedFilters, getTempOthers, getSavedOthers, removeOthers, getSavedSubFieldData , updateSubField, saveSubFieldData, updateFilters} from '../FieldsTab/fieldsSlice';
import { getJsonValue, updateFieldsJson } from '../../store/jsonReducer';
import useLocalStorage from '../../hooks/useLocalStorage';

import { buildFieldJson } from '../../utils/formatTime';

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ padding: '24px 0' }}>
          <Box>{children}</Box>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function ParametersContainer({ selectedField, handleSubFieldModal, selectedNestedField }) {
  const [value, setValue] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const dispatch = useDispatch();
  const fieldsValue = useSelector(getAllFields);
  const getTempFilterVal = useSelector(getTempFilters)
  const getSavedFilter = useSelector(getSavedFilters)
  const getTempOthersVal = useSelector(getTempOthers)
  const getSavedOther = useSelector(getSavedOthers)
 
  const savedSubFieldData = useSelector(getSavedSubFieldData);
  const tempSubFieldData = useSelector(getTempSubFieldData);
  const JsonValue = useSelector(getJsonValue);
  const [jsonCreator, setJsonCreator] = useLocalStorage('createdJson', null);
  const [saveParams,setSaveParams] = useState(false)
  console.log(getSavedFilter,getTempFilterVal,"asd")
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const handleNestedSubFieldModal = () => {
    setIsOpen(false);
  };
  useEffect(() => {
    updateSubField(savedSubFieldData)
  }, [tempSubFieldData])
  
  useEffect(()=>{
    if(saveParams)
      handleSubFieldModal(false)
  },[saveParams])
  
  const handleSaveParameters = () => {
    console.log(fieldsValue,getTempOthersVal,tempSubFieldData,getTempFilterVal)
    const newObj = buildFieldJson(fieldsValue,getTempOthersVal,tempSubFieldData,getTempFilterVal)
    console.log(newObj,"newObj")
    dispatch(saveFilters(getTempFilterVal))
    dispatch(saveSubFieldData(tempSubFieldData))
    dispatch(updateFieldsJson(newObj));
    setSaveParams(true)
  };
  const handleCancel = () => {
    dispatch(updateSubField(savedSubFieldData))
    dispatch(updateFilters(getSavedFilter))
    handleSubFieldModal(false)
  };
  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs
          TabIndicatorProps={{ style: { background: 'none' } }}
          value={value}
          onChange={handleChange}
          aria-label="basic tabs example"
        >
          <Tab label="Subfield" {...a11yProps(0)} />
          <Tab label="Filters" {...a11yProps(1)} />
          <Tab label="Others" {...a11yProps(2)} />
        </Tabs>
      </Box>
      <TabPanel value={value} index={0}>
        <SubFieldParameter selectedField={selectedField} selectedNestedField={selectedNestedField}/>
      </TabPanel>
      <TabPanel value={value} index={1}>
        <FiltersParameter selectedField={selectedField} selectedNestedField={selectedNestedField}/>
      </TabPanel>
      <TabPanel value={value} index={2}>
        <OthersParameters parameterID={selectedField} selectedNestedField={selectedNestedField}/>
      </TabPanel>
      <div className="flex-container">
        <Button color="tertiary" variant="outlined" onClick={() => handleCancel()}>
          Cancel
        </Button>
        <Button color="secondary" variant="outlined" onClick={() => setIsOpen(true)}>
          Add Fields
        </Button>
        <Button variant="contained" color="primary" onClick={() => handleSaveParameters()}>
          Save Parameters
        </Button>
      </div>
      <CustomModal
        showModal={isOpen}
        bodyComponent={<NestedSubFieldContainer handleNestedSubFieldModal={handleNestedSubFieldModal} selectedField={selectedField}/>}
        className={'Modal nestedfields'}
      />
      
    </Box>
  );
}
