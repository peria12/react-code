import Button from '@mui/material/Button';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IconButton } from '@mui/material';
import Iconify from '../../components/iconify';
import { addFilters, getTempFilters } from '../FieldsTab/fieldsSlice';
import TableComponent from '../../components/TableComponent';

const inlineFormStyles = {
  display: 'flex',
  gap: '8px',
};

const FiltersParameter = ({ selectedField }) => {
  const dispatch = useDispatch();
  const getTempFilterVal = useSelector(getTempFilters)
  // const getSavedFilter = useSelector(getSavedFilters)
  const [filterIDType, setFilterIDType] = useState('');
  const [filterInputId,setFilterInputId] = useState('');
  const [filterIds, setFilterIds]= useState([]);
  const getFiltersByField = () => {
    const filterVal = getTempFilterVal.filter(item=> item?.filterObj?.selectedField === selectedField)
    console.log(filterVal,"filterval")
    if(filterVal.length !== 0){
      console.log(filterVal[0].filterObj.filter.id_type,filterVal[0])
      setFilterIds(filterVal[0].filterObj.filter.ids)
      setFilterIDType(filterVal[0].filterObj.filter.id_type)
    }
  }
  useEffect(()=>{
    getFiltersByField()
  },[])
  useEffect(()=>{
      dispatch(addFilters({"filterObj":{"selectedField":selectedField,"filter":{ "id_type": filterIDType, "ids": filterIds }}}));
  },[filterIds])

  

  const handleAddFilterID = (event) => {
    const { name, value } = event.target;
    console.log(name,value,"namevlaue")
    if(name === "filterIDType"){
      setFilterIDType(value)
    }
    if(name === "filterID"){
      setFilterInputId(value)
    }
  };
  const formSubmitHandler = (event) => {
    event.preventDefault();
    // { "id_type": "port_ft_id", "ids": [ "27201" ] }
    setFilterIds(ids => [...ids, filterInputId]);
  };
  const columns = [
    { field: 'filterID', headerName: 'Filter IDs', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          setFilterIds(oldValues => {return oldValues.filter(item => item !==params.id )})
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];
  let formatFilter = []
  function formatFilterData(){
    filterIds.forEach(itemid=>{
      formatFilter = [...formatFilter,{id:itemid,filterID:itemid}]
  })
    return formatFilter
  }

  return (
    <>
      <form style={inlineFormStyles} onSubmit={formSubmitHandler}>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
          ID Type
        </Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', alignItems: 'center', width: 200 }}>
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            name="filterIDType"
            value={filterIDType}
            onChange={handleAddFilterID}
            inputProps={{ 'aria-label': 'Add Sub Fields' }}
          />
        </Paper>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>ID</Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', alignItems: 'center', width: 200 }}>
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            onChange={handleAddFilterID}
            name="filterID"
            inputProps={{ 'aria-label': 'Add Sub Fields' }}
          />
        </Paper>
        <Button color="secondary" variant="outlined" type="submit">
          Add Filter Id
        </Button>
      </form>
      <TableComponent rows={formatFilterData()} columns={columns}/>
    </>
  );
};
// formatFilterData()
export default FiltersParameter;
