import { IconButton } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import Iconify from '../../components/iconify';
import { removeSubField } from '../FieldsTab/fieldsSlice';
import TableComponent from '../../components/TableComponent';

const SubFieldParameterTable = ({ selectedField, selectedNestedField }) => {
  const dispatch = useDispatch();

  const subFieldData = useSelector((state) => state.fields?.tempSubFieldData);
  const nestedKey = selectedNestedField || selectedField
  const columns = [
    { field: 'subFieldValue', headerName: 'Subfield', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation(); // don't select this row after clicking
          dispatch(removeSubField(params.id));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <TableComponent rows={subFieldData.filter((item) => item.fieldName === selectedField && item.nestedKey === nestedKey)} columns={columns}/>
  );
};

export default SubFieldParameterTable;
