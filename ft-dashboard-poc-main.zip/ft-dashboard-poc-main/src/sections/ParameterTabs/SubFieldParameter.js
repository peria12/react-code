import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Button from '@mui/material/Button';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import SubFieldParameterTable from './SubFieldParameterTable';

import { getJsonValue } from '../../store/jsonReducer';
import { addSubField, getTempSubFieldData } from '../FieldsTab/fieldsSlice';

const inlineFormStyles = {
  display: 'flex',
  gap: '8px',
};

const SubFieldParameter = ({ selectedField, selectedNestedField }) => {
  const dispatch = useDispatch();
  const subFieldValue = useSelector(getTempSubFieldData);
  const jsonValue = useSelector(getJsonValue);
  console.log('Route ID', jsonValue, selectedField);

  const [subField, setSubField] = useState('');
  const [error, setError] = useState(false);

  const handleSubfield = () => {
    const isPresent = subFieldValue.some((item) => item.subFieldValue === subField);
    if (!isPresent) {
      setError(false);
      dispatch(
        addSubField({
          id: subField,
          subFieldValue: subField,
          subFieldName: 'sub_fields',
          fieldName: selectedField,
          nestedKey: selectedNestedField || selectedField,
          isArray: true,
        })
      );
      setSubField("")
    } else {
      setError(true);
    }
  };

  return (
    <>
      <div style={inlineFormStyles}>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
          Sub field
        </Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', alignItems: 'center', width: 250 }}>
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            placeholder=""
            inputProps={{ 'aria-label': 'Add Sub Fields' }}
            value={subField}
            onChange={(e) => setSubField(e.target.value)}
          />
        </Paper>
        <Button color="secondary" variant="outlined" onClick={(e) => handleSubfield()}>
          Add Subfield
        </Button>
        {error && <small className="error">SubField already added</small>}
      </div>
      <SubFieldParameterTable selectedField={selectedField} selectedNestedField={selectedNestedField} />
    </>
  );
};

export default SubFieldParameter;
