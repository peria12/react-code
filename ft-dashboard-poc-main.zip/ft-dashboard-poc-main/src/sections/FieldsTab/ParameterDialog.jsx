import Dialog from '@mui/material/Dialog';
import ParametersContainer from '../ParameterTabs/ParametersContainer';
// import { useEffect } from 'react';

const dialogContainer = {
  '& .MuiDialog-paper': {
    width: '100%',
    maxWidth: '90%',
    height: '80%',
  },
  '& .MuiDialogContent-root': {
    border: 'none',
    padding: '6px 24px 16px',
  },
  '& .MuiDialogActions-root': {
    padding: '30px 24px 24px',
    display: 'flex',
    justifyContent: 'space-between',
  },
};

const ParameterDialog = (props) => {
  const { onClose, selectedValue, open } = props;

  const handleClose = () => {
    onClose(selectedValue);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="scroll-dialog-title"
      aria-describedby="scroll-dialog-description"
      sx={dialogContainer}
    >
      <ParametersContainer />
    </Dialog>
  );
};

export default ParameterDialog;
