import { useState } from 'react';
import { IconButton, Box } from '@mui/material';
import CardContent from '@mui/material/CardContent';
import { DataGrid } from '@mui/x-data-grid';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import ConfirmationDialog from '../../components/ConfirmationDialog';
import { getAllFields, removeFields } from './fieldsSlice';
import Iconify from '../../components/iconify';
import TableNoData from '../../components/TableNoData';
import CustomModal from '../../components/CustomModal';
import ParametersContainer from '../ParameterTabs/ParametersContainer';
import TableComponent from '../../components/TableComponent';


const SelectedFieldsListTable = () => {
  const dispatch = useDispatch();
  const fieldName = useSelector(getAllFields);
  const [isOpen, setIsOpen] = useState(false)
  const [selectedField, setSelectedField] = useState(null)
  const handleSubFieldModal = (value) => {
    setIsOpen(value)
  }
  const columns = [
    { field: 'name', headerName: 'Fields', flex: 0.5, editable: false, sortable: false },
    {
      field: 'parameters',
      headerName: 'Parameters',
      flex: 1,
      editable: false,
      sortable: false,
      renderCell: (params) => {
        const handleOpenParameters = () => {
          setSelectedField(params.id)
          setIsOpen(true)
        };
        return (
          <button
            style={{
              backgroundColor: '#E2F3F4',
              color: '#000000CC',
              cursor: 'pointer',
              textAlign: 'start',
              border: 'none',
              width: '100%',
              height: '45px',
            }}
            onClick={handleOpenParameters}
          >
            Parameters
          </button>
        );
      },
    },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation(); // don't select this row after clicking
          <ConfirmationDialog fieldName={fieldName} rowID={params.id} />;
          dispatch(removeFields(params.id));
          // console.log(params.id);
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <>
      <TableComponent rows={fieldName} columns={columns} />
      <CustomModal
        showModal={isOpen}
        bodyComponent={<ParametersContainer selectedField={selectedField} handleSubFieldModal={handleSubFieldModal} />}
        className={"Modal selectedfields"}
      />
    </>
  );
};

export default SelectedFieldsListTable;
