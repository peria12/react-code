import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  fieldsNameList: [],
  tempSubFieldData: [],
  filters: [],
  others: [],
  saveFilters: [],
  saveOthers:[],
  nestedFieldsName:[],
  savedSubFieldData: [],
};

const fieldsSlice = createSlice({
  name: 'fields',
  initialState,
  reducers: {
    saveSubFieldData: (state, { payload }) => {
      state.savedSubFieldData = payload
    },
    addFields: (state, { payload }) => {
      state.fieldsNameList.push(payload);
    },
    removeFields: (state, { payload }) => {
      state.fieldsNameList = state.fieldsNameList.filter((fieldName) => fieldName.id !== payload);
    },
    addSubField: (state, { payload }) => {
      state.tempSubFieldData.push(payload)
    },
    removeSubField: (state, { payload }) => {
      state.tempSubFieldData = state.tempSubFieldData.filter((subFieldName) => subFieldName.id !== payload);
    },
    addFilters: (state, { payload }) => {
      state.filters = [
        ...state.filters.filter(x => x.filterObj.parameterID !== payload.filterObj.parameterID),
        payload,
      ]
    },
    updateFilters: (state, { payload }) => {
      state.filters = payload
    },
    saveFilters: (state, { payload }) => {
      state.saveFilters = payload
    },
    removeFilters: (state, { payload }) => {
      state.filters = state.filters.filter((filterName) => filterName.id !== payload);
    },
    resetFilters: (state) => {
      state.filters = []
    },
    addOthers: (state, { payload }) => {
      state.others.push(payload);
    },
    saveOthers: (state, { payload }) => {
      state.saveOthers = payload
    },
    resetOthers: (state) => {
      state.others = []
    },
    removeOthers: (state, { payload }) => {
      state.others = state.others.filter((otherName) => otherName.subFieldName !== payload);
      console.log('deleted others item');
    },
    resetFieldForm: () => {
      return initialState
    },
    addNestedField: (state, { payload }) => {
      state.nestedFieldsName.push(payload)
    },
    updateSubField: (state, { payload }) => {
      state.tempSubFieldData = payload
    },
    
  },
});

export default fieldsSlice.reducer;
// export actions
export const {
  addFields,
  removeFields,
  addSubField,
  removeSubField,
  updateSubField,
  addFilters,
  saveFilters,
  updateFilters,
  removeFilters,
  resetFilters,
  addOthers,
  saveOthers,
  removeOthers,
  resetFieldForm,
  addNestedField,
  saveSubFieldData,
} = fieldsSlice.actions;

// console.log(fieldsSlice.actions);

// export data
export const getAllFields = (state) => state.fields?.fieldsNameList;
export const getTempSubFieldData = (state) => state.fields?.tempSubFieldData;
export const getTempFilters = (state) => state.fields?.filters;
export const getSavedFilters = (state) => state.fields?.saveFilters;
export const getTempOthers = (state) => state.fields?.others;
export const getSavedOthers = (state) => state.fields?.saveOthers;
export const getNestedFields = (state) => state.fields?.nestedFieldsName;
export const getSavedSubFieldData = (state) => state.fields?.savedSubFieldData;

