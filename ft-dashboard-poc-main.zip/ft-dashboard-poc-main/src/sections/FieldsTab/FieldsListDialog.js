import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import { useSelector } from 'react-redux';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import InputBase from '@mui/material/InputBase';
import InputLabel from '@mui/material/InputLabel';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Paper from '@mui/material/Paper';
import fieldName from '../../_mock/fieldsname';
import AuthenticationMessage from '../../components/authentication-message';
// import { useEffect } from 'react';
import { getAllFields } from './fieldsSlice';

const dialogContainer = {
  '& .MuiDialog-paper': {
    width: '100%',
    maxWidth: '1122px',
  },
  '& .MuiDialogContent-root': {
    border: 'none',
    padding: '6px 24px 16px',
  },
  '& .MuiDialogActions-root': {
    padding: '30px 24px 24px',
    display: 'flex',
    justifyContent: 'space-between',
  },
};

const FieldsListDialog = ({onClose, selectedValue, open }) => {


  const handleClose = () => {
    onClose(selectedValue);
  };

  const handleCancelButton = (value) => {
    onClose(value);
  };
  const handleListItemDoubleClick = (event, value) => {
    console.log(event.target.innerHTML,value);

    onClose(value)
  };
  const handleSearchBox = (event) => {
    console.log(event.target.value);
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="scroll-dialog-title"
        aria-describedby="scroll-dialog-description"
        sx={dialogContainer}
      >
        <DialogTitle sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }} id="scroll-dialog-title">
          <InputLabel>Field</InputLabel>
          <Paper
            component="form"
            sx={{
              display: 'flex',
              alignItems: 'center',
              width: 265,
              height: '40px',
              marginLeft: '5px',
            }}
          >
            <InputBase
              sx={{ ml: 1, flex: 1 }}
              placeholder=""
              onInput={(e) => handleSearchBox(e)}
              inputProps={{ 'aria-label': '' }}
            />
          </Paper>
          <Button sx={{ marginLeft: '10px' }} color="secondary" variant="outlined">
            Search Field
          </Button>
        </DialogTitle>
        <DialogContent>
          <DialogContentText
            id="scroll-dialog-description"
            // ref={descriptionElementRef}
            tabIndex={-1}
            sx={{ height: '350px', overflowY: 'scroll' }}
          >
            <List>
              {fieldName?.map((value) => (
                <ListItem key={value}>
                  <ListItemText primary={value} onDoubleClick={(event) => handleListItemDoubleClick(event)} />
                </ListItem>
              ))}
            </List>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <AuthenticationMessage />
          <Button color="tertiary" variant="outlined" onClick={handleCancelButton}>
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default FieldsListDialog;
