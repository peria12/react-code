import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    jsonValue:{}
}
const createJsonReducer = createSlice({
  name: "createJsonReducer",
  initialState,
  reducers: {

    updateFieldsJson: (state, {payload} ) => ({ ...state, jsonValue: { ...state.jsonValue, fields: payload}}),

    updateEntitiesJson: (state, {payload} ) => ({ ...state, jsonValue: { ...state.jsonValue, entities: payload}}),

    updateIdDateJson: (state, {payload}) => ({ ...state, jsonValue: { ...state.jsonValue, id_date: payload}}),

    updateIdTypeJson: (state, {payload}) => ({ ...state, jsonValue: { ...state.jsonValue, id_type: payload}}),

    updateDateJson: (state, {payload}) => ({ ...state, jsonValue: { ...state.jsonValue, dates: payload}}),
    
    updateDateInfoJson: (state, {payload}) => ({ ...state, jsonValue: { ...state.jsonValue, date_info: payload}})
  },
});

export const { 
  updateFieldsJson, 
  updateEntitiesJson, 
  updateDateJson, 
  updateIdDateJson, 
  updateIdTypeJson, 
  updateDateInfoJson 
} = createJsonReducer.actions;
export default createJsonReducer.reducer;
export const getJsonValue = (state) => state.createJson;
