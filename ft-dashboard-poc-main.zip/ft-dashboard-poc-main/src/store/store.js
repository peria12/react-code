import { configureStore } from '@reduxjs/toolkit';
import fieldsSlice from '../sections/FieldsTab/fieldsSlice';
import entitiesSlice from '../sections/EntitiesTabs/entitiesSlice';
import createJsonReducer from './jsonReducer';
import datesSlice from '../sections/DatesTabs/datesSlice';

export const store = configureStore({
  reducer: {
    fields: fieldsSlice,
    entities: entitiesSlice,
    createJson: createJsonReducer,
    dates: datesSlice,
  },
});
