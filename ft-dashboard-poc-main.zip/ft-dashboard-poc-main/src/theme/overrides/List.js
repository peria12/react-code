export default function List(theme) {
  return {
    MuiList: {
      styleOverrides: {
        root: {
          color: theme.palette.grey[800],
          width: '100%',
          background: theme.palette.secondary.light,
        },
      },
    },
    MuiListItem: {
      styleOverrides: {
        root: {
          padding: '0 auto',
          height: '30px',
          cursor: 'pointer',
          '&:nth-of-type(even)': { backgroundColor: theme.palette.grey[100] },
          '&:hover': {
            backgroundColor: theme.palette.secondary.dark,
            color: theme.palette.secondary.contrastText,
          },
        },
      },
    },
  };
}
