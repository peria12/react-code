import { alpha } from '@mui/material/styles';

// ----------------------------------------------------------------------

export default function Button(theme) {
  return {
    MuiButtonBase: {
      styleOverrides: {
        root: {
          disableRipple: true, // No more ripple, on the whole application!
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: '4px',
          width: '150px',
          height: '45px',
          backgroundColor: theme.palette.primary.main,
          color: theme.palette.primary.contrastText,
          boxShadow: 'none',
          '&:hover': {
            backgroundColor: theme.palette.primary.containedInherit,
            color: theme.palette.primary.contrastText,
            border: `2px solid ${theme.palette.primary.main}`,
          },
        },
        sizeLarge: {
          height: 48,
        },
        containedInherit: {
          color: theme.palette.grey[800],
          boxShadow: theme.customShadows.z8,
          '&:hover': {
            backgroundColor: theme.palette.primary.contrastText,
          },
        },
        containedPrimary: {
          boxShadow: 'none',
        },
        outlinedPrimary: {
          boxShadow: 'none',
          backgroundColor: theme.palette.primary.contrastText,
          color: theme.palette.primary.main,
          border: `2px solid ${theme.palette.primary.main}`,
          '&:hover': {
            color: theme.palette.primary.main,
            backgroundColor: theme.palette.primary.contrastText,
            border: `2px solid ${theme.palette.primary.main}`,
          },
        },
        containedSecondary: {
          boxShadow: theme.customShadows.secondary,
        },
        outlinedSecondary: {
          boxShadow: 'none',
          backgroundColor: theme.palette.secondary.contrastText,
          color: theme.palette.secondary.dark,
          border: `2px solid ${theme.palette.secondary.dark}`,
          '&:hover': {
            backgroundColor: theme.palette.secondary.main,
            color: theme.palette.secondary.contrastText,
            border: `2px solid ${theme.palette.secondary.main}`,
          },
        },
        outlinedTertiary: {
          backgroundColor: theme.palette.tertiary.contrastText,
          color: theme.palette.tertiary.main,
          border: `2px solid ${theme.palette.tertiary.dark}`,
          '&:hover': {
            backgroundColor: theme.palette.tertiary.dark,
            color: theme.palette.secondary.contrastText,
            border: `2px solid ${theme.palette.tertiary.dark}`,
          },
        },
        // outlinedInherit: {
        //   border: `1px solid ${alpha(theme.palette.grey[500], 0.32)}`,
        //   '&:hover': {
        //     backgroundColor: theme.palette.action.hover,
        //   },
        // },
        outlinedError: {
          boxShadow: 'none',
          backgroundColor: theme.palette.error.contrastText,
          color: theme.palette.error.main,
          border: `2px solid ${theme.palette.error.main}`,
          '&:hover': {
            backgroundColor: theme.palette.error.main,
            color: theme.palette.error.contrastText,
            border: `2px solid ${theme.palette.error.main}`,
          },
        },
        textInherit: {
          '&:hover': {
            backgroundColor: theme.palette.action.hover,
          },
        },
      },
    },
    MuiIconButton: {
      styleOverrides: {
        root: {
          borderRadius: '3px',
          boxShadow: '0px 0px 0.2px #7777771A',
          height: '45px',
          width: '45px',
          '&:hover': {
            background: 'transparent',
          },
        },
      },
    },
    MuiToggleButton: {
      styleOverrides: {
        root: {
          borderRadius: '4px',
          padding: '8px 24px',
          height: '45px',
          '&.Mui-selected': {
            backgroundColor: theme.palette.secondary.light,
            border: `2px solid ${theme.palette.secondary.dark}`,
          },
          '&.MuiToggleButtonGroup-grouped:not(:first-of-type)': {
            marginLeft: '-2px',
            borderLeft: `2px solid ${theme.palette.secondary.dark}`,
          },
        },
      },
    },
  };
}
