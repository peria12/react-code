// ----------------------------------------------------------------------

export default function Tabs() {
  return {
    MuiTab: {
      styleOverrides: {
        root: {
          borderRadius: '8px 8px 0px 0px',
          border: '1px solid #E0E0E0',
          borderBottom: 'none',
          minWidth: 150,
          '&.Mui-selected': {
            background: '#F5F5F5',
            borderBottom: 'none',
            color: '#000000',
          },
        },
      },
    },
  };
}
