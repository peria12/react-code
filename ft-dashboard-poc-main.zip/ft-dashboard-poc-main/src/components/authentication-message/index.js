import AuthenticationMessage from './AuthenticationMessage';

export default AuthenticationMessage;
