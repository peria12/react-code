import { InputBase, Paper } from '@mui/material';
import { useState } from 'react';

const Filter = () => {
  const [filter, setFilter] = useState('');

  return (
    <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 200, marginBottom: '40px' }}>
      <InputBase
        onChange={(e) => setFilter(e.target.value)}
        value={filter}
        sx={{ ml: 1, flex: 1 }}
        inputProps={{ 'aria-label': 'Add key' }}
      />
    </Paper>
  );
};

export default Filter;
