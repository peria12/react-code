import ConfirmationDialog from './ConfirmationDialog';

export default ConfirmationDialog;
