import { Box } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import { useState } from 'react';
import Iconify from '../iconify/Iconify';

const ConfirmationDialog = ({ fieldName, rowID }) => {
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <Button variant="outlined" onClick={handleClickOpen}>
        Open alert dialog
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent
          sx={{
            // height: 300,
            // width: 500,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
          }}
        >
          <Box sx={{ display: 'contents' }} id="alert-dialog-description">
            <Iconify width="44px" height="44px" icon={'ph:warning'} sx={{ color: '#D80000' }} />
            <h3>Confirmation</h3>
            Are you sure you want to delete {fieldName} fields ?
          </Box>
          <DialogActions sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: '40px' }}>
            <Button variant="outlined" color="tertiary" onClick={handleClose} autoFocus>
              Cancel
            </Button>
            <Button variant="contained" color="warning" onClick={handleClose}>
              Delete
            </Button>
          </DialogActions>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ConfirmationDialog;
