const ExportIcon = () => {
    return (<svg xmlns="http://www.w3.org/2000/svg" width="14.958" height="11.744" viewBox="0 0 14.958 11.744">
    <g id="Group_3390" data-name="Group 3390" transform="translate(-2165.25 1021.091)">
      <g id="Group_3422" data-name="Group 3422">
        <line id="Line_140" data-name="Line 140" x1="5.784" transform="translate(2166 -1020.341)" fill="none" stroke="#8c8c8c" strokeLinecap="round" strokeWidth="1.5"/>
        <line id="Line_141" data-name="Line 141" y1="11.563" transform="translate(2166 -1021)" fill="none" stroke="#8c8c8c" strokeWidth="1.5"/>
        <line id="Line_142" data-name="Line 142" x2="5.784" transform="translate(2166 -1010.097)" fill="none" stroke="#8c8c8c" strokeLinecap="round" strokeWidth="1.5"/>
        <path id="Icon_ionic-md-download" data-name="Icon ionic-md-download" d="M9.711,5.223H6.937V0H2.774V5.223H0l4.855,6.094Z" transform="translate(2168.892 -1010.63) rotate(-90)" fill="#8c8c8c"/>
      </g>
    </g>
  </svg>
  )
}
export default ExportIcon