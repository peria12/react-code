const ImportIcon = () => {
    return (<svg xmlns="http://www.w3.org/2000/svg" width="14.958" height="11.744" viewBox="0 0 14.958 11.744">
        <g id="Group_3391" data-name="Group 3391" transform="translate(0.75 0.091)">
            <g id="Group_3421" data-name="Group 3421">
                <line id="Line_140" data-name="Line 140" x1="5.784" transform="translate(0 10.903)" fill="none" stroke="#8c8c8c" strokeLinecap="round" strokeWidth="1.5" />
                <line id="Line_141" data-name="Line 141" y2="11.563" fill="none" stroke="#8c8c8c" strokeWidth="1.5" />
                <line id="Line_142" data-name="Line 142" x2="5.784" transform="translate(0 0.659)" fill="none" stroke="#8c8c8c" strokeLinecap="round" strokeWidth="1.5" />
                <path id="Icon_ionic-md-download" data-name="Icon ionic-md-download" d="M9.711,6.094H6.937v5.223H2.774V6.094H0L4.855,0Z" transform="translate(2.892 10.903) rotate(-90)" fill="#8c8c8c" />
            </g>
        </g>
    </svg>)
}
export default ImportIcon