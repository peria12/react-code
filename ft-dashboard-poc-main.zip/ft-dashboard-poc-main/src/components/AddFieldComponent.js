import { useState } from 'react';
import Button from '@mui/material/Button';
import CardContent from '@mui/material/CardContent';
import IconButton from '@mui/material/IconButton';
import InputBase from '@mui/material/InputBase';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Paper from '@mui/material/Paper';
import Iconify from './iconify/Iconify';
import FieldsListDialog from '../sections/FieldsTab/FieldsListDialog'

const dropDownStyle = {
  '& :focus': {
    position: 'absolute',
    background: '#fff',
    color: 'black',
    width: '300px',
    height: '150px',
    overflowX: 'hidden',
    overflowY: 'scroll',
    boxShadow: '0.47px 3px 10px #7777771A',
    top: '42px',
  },
};

const AddFieldComponent = ({tableComponent, handleSearchFieldOnChange, searchFieldValue, onSearchField, handleAddField, fieldName,error}) => {

  const [isOpen,setIsOpen]=useState(false)
  const handleFieldList = ()=>{
    setIsOpen(true)
  }
  const handleClose = ()=>{
    setIsOpen(false)
  }
  return (
    <CardContent>
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '20px' }}>
        <Paper
          component="form"
          sx={{
            display: 'flex',
            alignItems: 'center',
            width: 300,
            border: '1px solid #8E8E8E',
            position: 'relative',
          }}
        >
          <InputBase
            sx={{ ml: 1, flex: 1, border: 'none' }}
            placeholder="Search Fields"
            inputProps={{ 'aria-label': 'Search Fields' }}
            value={searchFieldValue}
            onChange={handleSearchFieldOnChange}
          />
          <IconButton className="searchBtn" sx={{ p: '10px' }} aria-label="search" onClick={() => onSearchField(searchFieldValue)}>
            <Iconify icon={'iconamoon:search-bold'} />
          </IconButton>
          <div className="dropdown" style={dropDownStyle}>
            {fieldName
              .filter((item) => {
                const searchTerm = searchFieldValue.toLowerCase();
                const fieldName = item.toLowerCase();
                return searchTerm && fieldName.startsWith(searchTerm) && fieldName !== searchTerm;
              })
              .map((value) => (
                <ListItem key={value} onClick={() => onSearchField(value)}>
                  <ListItemText primary={value} />
                </ListItem>
              ))}
          </div>
        </Paper>
        <Button variant="contained" color="primary" onClick={handleAddField}>
          Add Fields
        </Button>
        <IconButton
          color="primary"
          aria-label="search"
          onClick={handleFieldList}
          sx={{
            backgroundColor: '#55BCB2',
            '&:hover': {
              backgroundColor: '#55BCB2',
            },
          }}
        >
          <Iconify icon={'gridicons:menus'} sx={{ color: '#FFFFFF' }} />  
        </IconButton>
        <FieldsListDialog
          open={isOpen}
          onClose={handleClose}
        />
      </div>
      {error && <small className='error'>Field already added</small>}
        {tableComponent}
    </CardContent>
  );
};

export default AddFieldComponent;
