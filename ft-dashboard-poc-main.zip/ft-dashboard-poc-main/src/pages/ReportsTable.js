
import Box from '@mui/material/Box';

const ReportsTable = () => {

  return (
    <Box sx={{
        width: 1100,
        height: 500,
        margin: "80px auto",
        border: "1px solid grey"
      }}>
       
      Under Construction
    </Box>
  );
};

export default ReportsTable;
