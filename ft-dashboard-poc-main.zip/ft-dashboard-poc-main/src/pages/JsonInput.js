import { useEffect, useRef, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
// @mui
import { Button, Container } from '@mui/material';
import Backdrop from '@mui/material/Backdrop';
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';
import { styled } from '@mui/material/styles';
import { useDispatch, useSelector } from 'react-redux';

import AuthenticationMessage from '../components/authentication-message';
// components
import Iconify from '../components/iconify';
import ImportIcon from '../components/Icons/ImportIcon'
import ExportIcon from '../components/Icons/ExportIcon'
import Header from '../layouts/dashboard/header';
import { getJsonValue } from '../store/jsonReducer';
import '../theme/commonStyles.scss'

import useLocalStorage from "../hooks/useLocalStorage"
import { resetFieldForm } from "../sections/FieldsTab/fieldsSlice"
import { resetEntitiesForm, saveEntityData, updateSearchEntity } from "../sections/EntitiesTabs/entitiesSlice"
import { resetDatesForm } from "../sections/DatesTabs/datesSlice"
// sections
// ----------------------------------------------------------------------

const StyledRoot = styled('div')(({ theme }) => ({
  [theme.breakpoints.up('md')]: {
    display: 'flex',
    height: '100vh',
  },
}));
const userAgent = window.navigator.userAgent.toLowerCase()

const StyledContent = styled('div')(() => ({
  width: '100%',
  marginTop: '20px',
  minHeight: '100vh',
  display: 'flex',
  justifyContent: 'center',
  flexDirection: 'column',
}));

const textArea = {
  '& textarea': {
    boxSizing: 'border-box',
    width: '100%',
    margin: '20px 0px',
    padding: '10px',
    fontSize: '16px',
    background: '#FFFFFF 0% 0% no-repeat padding-box',
    boxShadow: '0.45px 2px 10px #7777771A',
    border: '1px solid #EAEAEA',
    borderRadius: '6px',
    outline: 'none',
    resize: 'none',
  },
};

// ----------------------------------------------------------------------

export default function LoginPage() {
  const jsonValue = useSelector(getJsonValue);
  console.log(jsonValue.jsonValue,"jsonValue")
  const navigate = useNavigate(); 

  const fileInputRef = useRef();
  const [jsonCreator, setJsonCreator] = useLocalStorage("createdJson", {})
  const [loading, setLoading] = useState(false);
  const [inputText, setInputText] = useState("");
  const [open, setOpen] = useState(false);
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [ b64String, setB64String ]=useState('')

  const ACCEPT_TEXT = '.txt,.json,application/json';
  const dispatch = useDispatch();

  const isJsonString = (json) => {
    console.log("isJsonString")
    let isValid = false
    const printError = function (error, explicit) {
      setErrorMsg(`[${explicit ? 'EXPLICIT' : 'INEXPLICIT'}] ${error.name}: ${error.message}`)
    }
    try {
      if (JSON.parse(json)) {
        setError(false)
  //      dispatch(createJson(JSON.parse(json)))
        setJsonCreator(JSON.parse(json))
      } isValid = true
    } catch (e) {
      setError(true)
      if (e instanceof SyntaxError) {
        printError(e, true);
      } else {
        printError(e, false);
      }
    }
    return isValid
  }
  useEffect(()=>{
    setInputText(JSON.stringify(jsonValue.jsonValue, null, 4))
  },[])
 
  const handleOnChange = (e) => {
    setInputText(e.target.value);
  };

  const handleInputChange = (e) => {
    const file = e.target.files[0];

    const reader = new FileReader();

    reader.onload = (e) => {
      const inputFile = e.target.result;
      setInputText(inputFile);
      isJsonString(inputFile)
    };

    reader.onerror = (e) => alert(e.target.error.name);
    reader.readAsText(file);
  };

  const handleTextFile = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const link = document.createElement('a');
    const content = document.querySelector('textarea').value;
    if (isJsonString(content)) {
      if (content?.length > 0) {
        const file = new Blob([content], { type: '.txt/plain,.json,application/json' });
        link.href = URL.createObjectURL(file);
        link.download = 'myFile.txt';
        link.click();
      }
      document.body.appendChild(link);
      URL.revokeObjectURL(link.href);
    }
  };

  const handleClearInput = () => {
    setJsonCreator({})
    setError(false)
    setErrorMsg("")
    setInputText("{}");
    dispatch(resetFieldForm())
    dispatch(resetEntitiesForm())
    dispatch(resetDatesForm())
  };

  const handleWizardClick = () => {
    if (isJsonString(inputText)) {
      navigate('/dal', { replace: true });
    }
  };
  const handleExcelFetch = async ()=>{
    window.chrome.webview.postMessage(JSON.stringify({message:'ExcelFileLoaded',data: "https://ft-dashboard-poc.netlify.app/assets/Portfolio-Prod.xlsx",calledfrom:"fetchdata"}));
  }
    
  
  const handleOpen = () => {
    if (userAgent === 'dalplugin') {
      handleExcelFetch()
    }
    else {
      // setLoading(true)
      // navigate('/reportstable', { replace: true });
    // fetch("assets/Portfolio-Prod.xlsx")
    //   .then( res => res.blob() )
    //   .then( blob => {
    //     const file = window.URL.createObjectURL(blob);
    //     window.location.assign(file);
    //   });
    }
    const test = {
      fields: [
        "portfoliolist",
        { ds_total_return_index: { lag: [30, 90] } },
        {
          fact_index_constituents: {
            sub_fields: [
              {
                asset3_esg: {
                  sub_fields: ["new", "new2"],
                  time_delta: 30
                }
              }
            ]
          }
        },
        {
          factset_index_constituents: {
            sub_fields: [
              "fsym_security_id",
              "fsym_regional_id",
              "fsym_listing_id",
              "qad_sec_id"
            ]
          }
        },
        {
          test: {
            sub_fields: [
              "tse",
              "fsym_retesgional_id",
              "fsym_ldsisting_id",
              "qad_sec_id",
              {
                ass_esg: {
                  sub_fields: [
                    "InnovationScore",
                    "ControversiesScore",
                    "HumanRightsScore",
                    "ManagementScore"
                  ],
                  time_delta: 30
                }
              },
              {
                as_sg: {
                  sub_fields: [
                    "InnovationScore",
                    "ControversiesScore",
                    "HumanRightsScore",
                    "ManagementScore"
                  ],
                  time_delta: 30
                }
              }
            ]
          }
        }
      ],
      id_type: "fs_bm_id",
      id_date: "2023-01-31",
      dates: ["2000-07-30", "2022-08-31"],
      date_info: { fill_missing: "no" },
      entities: ["SP50USD", "891800USD", "892400USD"]
    };
    const fieldsValue = [];
    const subFieldsValue = [];
    const othersValue = [];

    function getFieldItem(object) {
      object.forEach((item) => {
        console.log(item, "itemin");
        if(typeof item === "string"){
          fieldsValue.push({
            id: item,
            name: item
          });
      }
      else{
        const fieldkey = Object.entries(item);
        console.log(fieldkey, "Das");
        console.log(fieldkey[0][1], "Das");
        fieldsValue.push({
          id: fieldkey[0][0],
          name: fieldkey[0][0]
        });
        searchItem(item, fieldkey[0][0]);
      }
      });
      console.log([subFieldsValue, fieldsValue]);
      return [subFieldsValue, fieldsValue, othersValue];
    }

    function searchItem(item, fieldName) {
      Object.keys(item).forEach((key) => {
        const nestedKey = Object.keys(item)[0];
        console.log(nestedKey, "ds");
        const fieldkey = Object.entries(item[key]);
        console.log(fieldkey[0], "das");
        fieldkey.forEach((fielditem, index) => {
          console.log(fielditem[0], fielditem[1]);
          if (fielditem[0] === "sub_fields" && Array.isArray(fielditem[1])) {
            fielditem[1].forEach((val) => {
              if (typeof val === "string" || typeof val === "number") {
                subFieldsValue.push({
                  subFieldValue: val,
                  subFieldName: fielditem[0],
                  fieldName,
                  nestedKey,
                  isArray: true
                });
              } else if (typeof val === "object") {
                searchItem(val, fieldName);
              }
            });
          } else {
            const subkey = Object.entries(item[key]);
            othersValue.push({
              id: { [fielditem[0]]: fielditem[1] },
              subFieldValue: fielditem[1],
              subFieldName: subkey[index][0],
              fieldName,
              nestedKey: key,
              subFieldObjKey: item[key].sub_fields ? "sub_fields" : subkey[index][0]
            });
          }
        });
      });
    }

    // id: "new2"
    // subFieldValue: "new2"
    // subFieldName: "sub_fields"
    // fieldName: "fact_index_constituents"
    // nestedKey: "asset3_esg"
    // isArray: true
    const result = getFieldItem(test.fields);

    console.log(test.fields);
    console.log(result);

    const newObj = [];
    for (const [index, fieldName] of fieldsValue.entries()) {
      newObj.push({ [fieldName.name]: {} });
      for (const item of subFieldsValue) {
        if (fieldName.name === item.fieldName) {
          if (item.isArray) {
            const fieldame = fieldName.name;
            const subFieldName = item.subFieldName;
            const nestedKey = item.nestedKey;
            if (!newObj[index][fieldame][subFieldName]) {
              newObj[index][fieldame] = { [item.subFieldName]: [] };
            }
            console.log(fieldame, nestedKey);
            if (fieldame === nestedKey) {
              newObj[index][fieldame][subFieldName].push(item.subFieldValue);
            }
            if (fieldame !== nestedKey && item.subFieldName === "sub_fields") {
              const findnest = newObj[index][fieldame][subFieldName].find(
                (item) => {
                  return item[nestedKey];
                }
              );
              if (!findnest) {
                newObj[index][fieldame][subFieldName].push({
                  [item.nestedKey]: { sub_fields: [] }
                });
                const findnest = newObj[index][fieldame][subFieldName].find(
                  (item) => {
                    return item[nestedKey];
                  }
                );
                findnest[item.nestedKey][subFieldName].push(item.subFieldValue);
              }
              if (findnest) {
                findnest[item.nestedKey][subFieldName].push(item.subFieldValue);
              }
            }
          } else {
            console.log(item, "elseiff");
            if (item.fieldName !== item.nestedKey && !item?.isSubfieldObj) {
              const testm = newObj[index][item.fieldName][item.subFieldObjKey].find(
                (itm) => itm[item.nestedKey]
              );
              Object.assign(testm[item.nestedKey], { [item.subFieldName]: item.subFieldValue });
            } else {
              Object.assign(newObj[index][item.fieldName], { [item.subFieldName]: item.subFieldValue })

            }
          }
        }
      }
    }
    console.log(newObj)
  };



  return (
    <>
      <Helmet>
        <title> Login | DAL Plugin </title>
      </Helmet>


      <StyledRoot>
        <Header className="testcalss" onOpenNav={() => setOpen(true)} />

        <Container maxWidth="lg">
          <StyledContent>
            <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', marginTop: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: 10 }}>
                <input
                  className="file-input"
                  hidden
                  type="file"
                  multiple
                  ref={fileInputRef}
                  onChange={handleInputChange}
                  accept={`${ACCEPT_TEXT}`}
                />
                <Button
                  color="tertiary"
                  variant="outlined"
                  className="ImportIcon"
                  startIcon={<ImportIcon />}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    fileInputRef?.current?.click();
                  }}
                >
                  Import
                </Button>
                <Button
                  color="tertiary"
                  variant="outlined"
                  className="ExportIcon"
                  startIcon={<ExportIcon />}
                  onClick={handleTextFile}
                >
                  Export
                </Button>
              </div>
              <div>
                <Button
                  color="error"
                  variant="outlined"
                  startIcon={<Iconify icon={'mdi:trash'} />}
                  onClick={handleClearInput}
                >
                  Clear
                </Button>
              </div>
            </div>
            <Box sx={textArea}>
              <textarea rows={14} value={inputText} onChange={handleOnChange} />
              <small className='error'>{error && errorMsg}</small>
            </Box>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>
                <Button
                  color="tertiary"
                  variant="outlined"
                  className='closebtn'
                  onClick={() => {
                    if (userAgent === 'dalplugin')
                      window.chrome.webview.postMessage('CancelButtonClicked');
                  }}
                >
                  Cancel
                </Button>
              </div>
              <div style={{ display: 'flex', flexDirection: 'row' }}>
                <Button color="primary" variant="contained" style={{ marginRight: 15 }} onClick={handleWizardClick}>
                  Wizard
                </Button>
                <div>
                  <Button color="secondary" variant="outlined" onClick={handleOpen}>
                    Fetch Data
                  </Button>
                  <Backdrop
                    sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={loading}
                  >
                    <CircularProgress />
                  </Backdrop>
                </div>
              </div>
            </div>
            <AuthenticationMessage />
          </StyledContent>
        </Container>
      </StyledRoot>
    </>
  );
}
