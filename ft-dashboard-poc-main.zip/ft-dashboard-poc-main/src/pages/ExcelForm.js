import { useState} from 'react';
import CircularProgress from '@mui/material/CircularProgress';
import { Container } from '@mui/material';
import { Helmet } from 'react-helmet-async';
import { styled } from '@mui/material/styles';
import Header from '../layouts/dashboard/header';


const StyledRoot = styled('div')({
  display: 'flex',
  minHeight: '100%',
  overflow: 'hidden',
});
const ExcelForm = () => {
  const userAgent = window.navigator.userAgent.toLowerCase()
  const [ b64String, setB64String ]=useState('')
  fetch("assets/Portfolio-Prod.xlsx")
  .then((res) => res.blob())
  .then((blob) => {
    const reader = new FileReader();
    reader.onloadend = () => {
        // Use a regex to remove data url part
        const base64String = reader.result
            .replace('data:', '')
            .replace(/^.+,/, '');

        console.log(base64String);
        setB64String(base64String)
        if(userAgent === 'dalplugin')
        window.chrome.webview.postMessage('ExcelFileLoaded');
        // Logs wL2dvYWwgbW9yZ...
    };
    reader.readAsDataURL(blob);
  });
  const handleOnChange = (e) => {
    setB64String(e.target.value);
  };


  return (
    <>
      <Helmet>
        <title> Dashboard | DAL Plugin </title>
      </Helmet>
      <StyledRoot>
        <Header/>
        <Container maxWidth="lg" className='datafetch'>
          <p>Please wait while we are fetching the data</p>
          <CircularProgress />
          <textarea id="exceltextarea" style={{ visibility: 'hidden' }} value={b64String} onChange={handleOnChange}/>
        </Container>
      </StyledRoot>
    </>

  );
};

export default ExcelForm;
