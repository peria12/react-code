// ----------------------------------------------------------------------

const account = {
  displayName: 'Apurva Shah',
  email: 'apurva@franklintempelton.com',
  photoURL: '/assets/images/avatars/avatar_default.jpg',
};

export default account;
