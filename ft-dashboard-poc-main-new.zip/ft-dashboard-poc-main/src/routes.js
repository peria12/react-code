import { Navigate, useRoutes } from 'react-router-dom';
// layouts
import JsonInput from './pages/JsonInput';
import { DALPlugin } from './sections/dal';
import ParameterForm from './sections/dal/ParameterForm';
import LoginPage from './pages/LoginPages';
// ----------------------------------------------------------------------

export default function Router() {
  const routes = useRoutes([
    // {
    //   path: '/dashboard',
    //   element: <DashboardLayout />,
    //   children: [
    //     { element: <Navigate to="/dashboard/app" />, index: true },
    //     { path: 'app', element: <DashboardAppPage /> },
    //     { path: 'user', element: <UserPage /> },
    //     { path: 'products', element: <ProductsPage /> },
    //     { path: 'blog', element: <BlogPage /> },
    //   ],
    // },
    {
      path: '/json-input',
      element: <JsonInput />,
    },
    {
      path:'/',
      element:<LoginPage />
    },
    
    {
      path: 'dal',
      element: <DALPlugin />,
    },
    {
      path: 'parameter-subfield',
      element: <ParameterForm />,
    },
    // {
    //   path: 'login',
    //   element: <LoginPage />,
    // },
    {
      path: '*',
      element: <Navigate to="/404" replace />,
    },
  ]);

  return routes;
}
