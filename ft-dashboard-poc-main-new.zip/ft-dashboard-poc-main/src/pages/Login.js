
import {useState} from "react";
import { Grid,Paper,Avatar, TextField } from "@mui/material";
import {LockOutLinkedIcon} from "@mul"
import Button from "src/theme/overrides/Button";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import "./Login.css";



const [email, setEmail] = useState("");

const [password, setPassword] = useState("");
const [apiUrl, setApiurl] = useState("");

function validateForm() {

  return email.length > 0 && password.length > 0;

}

function handleSubmit(event) {
  event.preventDefault();
}

 const Login =() =>{
const Paperstyle={padding :20, height:'70vh', width:280,margin:"20px,auto"}
return (

  <div className="Login">

    <Form onSubmit={handleSubmit}>

      <Form.Group size="lg" controlId="email">

        <Form.Label>Email</Form.Label>

        <Form.Control

          autoFocus

          type="email"

          value={email}

          onChange={(e) => setEmail(e.target.value)}

        />

      </Form.Group>

      <Form.Group size="lg" controlId="password">

        <Form.Label>Password</Form.Label>

        <Form.Control

          type="password"

          value={password}

          onChange={(e) => setPassword(e.target.value)}

        />
 <Form.Label>apiUrl</Form.Label>

<Form.Control

  type="api url"

  value={apiUrl}

  onChange={(e) => setApiurl(e.target.value)}

/>
        

      </Form.Group>

      <Button block size="lg" type="submit" disabled={!validateForm()}>

        Login

      </Button>

    </Form>

  </div>

);

}
      export default Login
  



