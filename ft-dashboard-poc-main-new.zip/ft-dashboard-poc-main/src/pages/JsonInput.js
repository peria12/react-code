import { useEffect, useRef, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
// @mui
import { Button, Container } from '@mui/material';
import Backdrop from '@mui/material/Backdrop';
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';
import { styled } from '@mui/material/styles';
import { useDispatch, useSelector } from 'react-redux';
// import FileUploadIcon from '@mui/icons-material/FileUpload';
// import FileDownloadIcon from '@mui/icons-material/FileDownload';
// hooks
import AuthenticationMessage from '../components/authentication-message';
import useResponsive from '../hooks/useResponsive';
// components
import CopyrightText from '../components/copyright-text';
import Iconify from '../components/iconify';
import Header from '../layouts/dashboard/header';
import { createJson, getJsonValue } from '../store/jsonReducer';
import '../theme/commonStyles.scss'

import useLocalStorage from "../hooks/useLocalStorage"
// sections
// ----------------------------------------------------------------------

const StyledRoot = styled('div')(({ theme }) => ({
  [theme.breakpoints.up('md')]: {
    display: 'flex',
    height: '100vh',
  },
}));

// const StyledSection = styled('div')(({ theme }) => ({
//   width: '100%',
//   maxWidth: 480,
//   display: 'flex',
//   flexDirection: 'column',
//   justifyContent: 'center',
//   boxShadow: theme.customShadows.card,
//   backgroundColor: theme.palette.background.default,
// }));

const StyledContent = styled('div')(() => ({
  width: '100%',
  marginTop: '20px',
  minHeight: '100vh',
  display: 'flex',
  justifyContent: 'center',
  flexDirection: 'column',
}));

const textArea = {
  '& textarea': {
    boxSizing: 'border-box',
    width: '100%',
    margin: '20px 0px',
    padding: '10px',
    fontSize: '16px',
    background: '#FFFFFF 0% 0% no-repeat padding-box',
    boxShadow: '0.45px 2px 10px #7777771A',
    border: '1px solid #EAEAEA',
    borderRadius: '6px',
    outline: 'none',
    resize: 'none',
  },
};

// ----------------------------------------------------------------------

export default function LoginPage() {
  const jsonValue = useSelector(getJsonValue);
  const mdUp = useResponsive('up', 'md', 'xs');
  const navigate = useNavigate();

  const fileInputRef = useRef();
  const [jsonCreator, setJsonCreator] = useLocalStorage("createdJson",{})
  const [loading, setLoading] = useState(false);
  const [inputText, setInputText] = useState(jsonCreator === null ? {} : JSON.stringify(jsonCreator));
  const [open, setOpen] = useState(false);
  const [error,setError] = useState(false);
  const [errorMsg,setErrorMsg] = useState("");
  const ACCEPT_TEXT = '.txt,.json,application/json';
  const dispatch = useDispatch();
  
  const isJsonString = (json) => {
    console.log("isJsonString")
    let isValid = false
    const printError = function (error, explicit) {
      setErrorMsg(`[${explicit ? 'EXPLICIT' : 'INEXPLICIT'}] ${error.name}: ${error.message}`)
    }
    try {
      if(JSON.parse(json)){
        setError(false)
        dispatch(createJson(JSON.parse(json)))
        setJsonCreator(JSON.parse(json))
      } isValid = true
    } catch (e) {
      setError(true)
      if (e instanceof SyntaxError) {
        printError(e, true);
      } else {
        printError(e, false);
      }
    }
    return isValid
  }
  useEffect(()=>{
    if(jsonValue){
    setInputText( JSON.stringify(jsonCreator,null,4))
  }
  },[jsonCreator,jsonValue])
  const handleOnChange = (e) => {
    setInputText(e.target.value);
  };

  const handleInputChange = (e) => {
    const file = e.target.files[0];

    const reader = new FileReader();

    reader.onload = (e) => {
      const inputFile = e.target.result;
      setInputText(inputFile);
      isJsonString(inputFile)
    };

    reader.onerror = (e) => alert(e.target.error.name);
    reader.readAsText(file);
  };

  const handleTextFile = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const link = document.createElement('a');
    const content = document.querySelector('textarea').value;
    if(isJsonString(content)){
    if (content?.length > 0) {
      const file = new Blob([content], { type: '.txt/plain,.json,application/json' });
      link.href = URL.createObjectURL(file);
      link.download = 'myFile.txt';
      link.click();
    }
    document.body.appendChild(link);
    URL.revokeObjectURL(link.href);
    }
  };

  const handleClearInput = () => {
    setJsonCreator({})
    setError(false)
    setErrorMsg("")
    setInputText("{}");
  };

  const handleWizardClick = () => {
    if(isJsonString(inputText)){
    navigate('/dal', { replace: true });
    }
  };

  const handleClose = () => {
    setLoading(false);
  };

  const handleOpen = () => {
    setLoading(false);
  };



  return (
    <>
      <Helmet>
        <title> Login | DAL Plugin </title>
      </Helmet>
      {/* <div
        style={{
          width: '100%',
          height: '110px',
          position: 'fixed',
          borderBottom: '2px solid #B5B3B3',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <Logo
          sx={{
            position: 'fixed',
            top: { xs: 16, sm: 24, md: 40 },
            left: { xs: 16, sm: 24, md: 40 },
          }}
        />
        <Typography variant="h3" sx={{ px: 5, fontWeight: 600, fontSize: '28px !important' }}>
          Json Input
        </Typography>
      </div> */}

      <StyledRoot>
        <Header onOpenNav={() => setOpen(true)} />
        {/* {mdUp && (
          <styledSection>
            <Typography variant="h3" sx={{ px: 5, mt: 10, mb: 5 }}>
              Hi, Welcome Back
            </Typography>
            <img src="/assets/illustrations/illustration_login.png" alt="login" />
          </StyledSection>
        )} */}

        <Container maxWidth="lg">
          <StyledContent>
            <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', marginTop: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: 10 }}>
                <input
                  className="file-input"
                  hidden
                  type="file"
                  multiple
                  ref={fileInputRef}
                  onChange={handleInputChange}
                  accept={`${ACCEPT_TEXT}`}
                />
                <Button
                  color="primary"
                  variant="outlined"
                  startIcon={<Iconify icon={'ic:round-download'} />}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    fileInputRef?.current?.click();
                  }}
                >
                  Import
                </Button>
                <Button
                  color="secondary"
                  variant="outlined"
                  startIcon={<Iconify icon={'ic:round-upload'} />}
                  onClick={handleTextFile}
                >
                  Export
                </Button>
              </div>
              <div>
                <Button
                  color="error"
                  variant="contained"
                  startIcon={<Iconify icon={'mdi:trash'} />}
                  onClick={handleClearInput}
                >
                  Clear
                </Button>
              </div>
            </div>
            <Box sx={textArea}>
              <textarea rows={14} value={inputText} onChange={handleOnChange} />
              <small className='error'>{error && errorMsg}</small>
            </Box>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>
                <Button
                  color="tertiary"
                  variant="outlined"
                  onClick={() => {
                    navigate('/');
                  }}
                >
                  Cancel
                  {console.log(error,errorMsg)}
                </Button>
              </div>
              <div style={{ display: 'flex', flexDirection: 'row' }}>
                <Button color="primary" variant="contained" style={{ marginRight: 15 }} onClick={handleWizardClick}>
                  Wizard
                </Button>
                <div>
                  <Button color="primary" variant="outlined" onClick={handleOpen}>
                    Fetch Data
                  </Button>
                  <Backdrop
                    sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={loading}
                    onClick={handleClose}
                  >
                    <CircularProgress color="inherit" />
                  </Backdrop>
                </div>
              </div>
            </div>
            <AuthenticationMessage />
            <CopyrightText />
          </StyledContent>
        </Container>
      </StyledRoot>
    </>
  );
}
