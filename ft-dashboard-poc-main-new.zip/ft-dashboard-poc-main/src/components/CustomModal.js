import Modal from 'react-modal';
import Iconify from './iconify/Iconify';

function CustomModal({ showModal, Body, title, bodyComponenetRef, bodyComponent, className,closeModal }) {
  return (
    <Modal
      isOpen={showModal}
      className={className}
      ariaHideApp={false}
      contentLabel="onRequestClose Example"
      shouldCloseOnOverlayClick={false}
    >
      <div>
        <h2>{title}</h2>
        <button className="close-icon" onClick={closeModal}>
          <Iconify sx={{ cursor: 'pointer' }} icon={'charm:cross'}/>
        </button>
      </div>
      <div>{Body ? <Body ref={bodyComponenetRef} /> : bodyComponent}</div>
    </Modal>
  );
}

export default CustomModal;
