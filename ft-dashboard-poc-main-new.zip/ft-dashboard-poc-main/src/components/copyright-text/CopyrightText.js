const { Typography } = require('@mui/material');

const CopyrightText = () => {
  return (
    <Typography sx={{ color: '#ADADAD', margin: '40px 0px 10px', fontSize: '12px' }}>
      &copy; Copyright. All rights reserved.
    </Typography>
  );
};

export default CopyrightText;
