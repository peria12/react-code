import CopyrightText from './CopyrightText';

export default CopyrightText;
