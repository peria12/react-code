import { Typography } from '@mui/material';

const AuthenticationMessage = () => {
  return (
    <Typography sx={{ color: '#37A000', marginTop: '15px' }}>Authenticated into DAL Production Environment</Typography>
  );
};

export default AuthenticationMessage;
