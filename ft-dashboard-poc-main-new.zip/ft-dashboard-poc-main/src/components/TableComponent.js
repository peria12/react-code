import { DataGrid } from '@mui/x-data-grid';
import CardContent from '@mui/material/CardContent';
import TableNoData from './TableNoData';

export default function TableComponent({ rows, columns,tableHeight }) {
  return (
    <CardContent sx={{ padding: '24px 0px', height: tableHeight || 395, width: '100%' }}>
      <DataGrid
        rowHeight={48}
        rows={rows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        sx={{
          '&.MuiDataGrid-root .MuiDataGrid-columnHeader:focus, &.MuiDataGrid-root .MuiDataGrid-cell:focus-within': {
            outline: 'none',
          },
          overflowX: 'hidden',
        }}
        pageSizeOptions={[5]}
        disableRowSelectionOnClick
        hideFooterPagination={rows.length === 0}
        disableColumnMenu
        slots={{
          noRowsOverlay: TableNoData,
        }}
      />
    </CardContent>
  );
}
