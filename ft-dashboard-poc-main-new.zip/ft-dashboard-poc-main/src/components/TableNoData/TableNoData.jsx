import { Box } from '@mui/material';

function TableNoData() {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Box sx={{ mt: 1 }}>No Data</Box>
    </Box>
  );
}

export default TableNoData;
