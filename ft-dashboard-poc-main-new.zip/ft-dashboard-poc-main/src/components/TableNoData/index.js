import TableNoData from './TableNoData';

export default TableNoData;
