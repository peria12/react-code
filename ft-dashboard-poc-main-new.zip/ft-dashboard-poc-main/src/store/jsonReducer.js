import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    jsonValue:null
}
const createJsonReducer = createSlice({
  name: "createJsonReducer",
  initialState,
  reducers: {
    createJson: (state, action) =>{
      return {...state, jsonValue:action.payload}

    }
  },
});

export const { createJson } = createJsonReducer.actions;
export default createJsonReducer.reducer;
export const getJsonValue = (state) => state.createJson?.jsonValue;
