import Button from '@mui/material/Button';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addFilters } from '../FieldsTab/fieldsSlice';
import FiltersParameterTable from './FiltersParameterTable';

const inlineFormStyles = {
  display: 'flex',
  gap: '8px',
};

const FiltersParameter = ({ parameterID }) => {
  const initialState = {
    filterIDType: '',
    filterID: '',
  };
  const [filterIDValue, setFilterIDValue] = useState(initialState);
  const dispatch = useDispatch();

  const handleAddFilterID = (event) => {
    const { name, value } = event.target;
    setFilterIDValue((prev) => {
      return { ...prev, [name]: value };
    });
  };

  const formSubmitHandler = (event) => {
    event.preventDefault();
    setFilterIDValue(filterIDValue);
    dispatch(addFilters({ filterIDValue, parameterID }));
  };

  return (
    <>
      <form style={inlineFormStyles} onSubmit={formSubmitHandler}>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
          ID Type
        </Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', alignItems: 'center', width: 200 }}>
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            name="filterIDType"
            onChange={handleAddFilterID}
            inputProps={{ 'aria-label': 'Add Sub Fields' }}
          />
        </Paper>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>ID</Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', alignItems: 'center', width: 200 }}>
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            onChange={handleAddFilterID}
            name="filterID"
            inputProps={{ 'aria-label': 'Add Sub Fields' }}
          />
        </Paper>
        <Button color="secondary" variant="outlined" type="submit">
          Add Filter Id
        </Button>
      </form>
      <FiltersParameterTable />
    </>
  );
};

export default FiltersParameter;
