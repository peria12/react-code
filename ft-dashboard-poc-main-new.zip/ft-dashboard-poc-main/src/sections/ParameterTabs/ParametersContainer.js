import { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import PropTypes from 'prop-types';
import Button from '@mui/material/Button';
import { useDispatch, useSelector } from 'react-redux';

import FiltersParameter from './FiltersParameter';
import OthersParameters from './OthersParameters';
import SubFieldParameter from './SubFieldParameter';
import CustomModal from '../../components/CustomModal';
import NestedSubFieldContainer from './NestedSubFieldContainer';

import { getAllFields, getSubFieldValue } from '../FieldsTab/fieldsSlice';
import { createJson, getJsonValue } from '../../store/jsonReducer';
import useLocalStorage from '../../hooks/useLocalStorage';

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ padding: '24px 0' }}>
          <Box>{children}</Box>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function ParametersContainer({ selectedField, handleSubFieldModal }) {
  const [value, setValue] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const dispatch = useDispatch();
  const fieldsValue = useSelector(getAllFields);
  const subFieldsValue = useSelector(getSubFieldValue);
  const JsonValue = useSelector(getJsonValue);
  const [jsonCreator, setJsonCreator] = useLocalStorage('createdJson', null);

  console.log(fieldsValue, subFieldsValue, 'dasd');
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const handleNestedSubFieldModal = () => {
    setIsOpen(false);
  };
  useEffect(() => {
    setJsonCreator((prevState) => ({
      ...prevState,
      fields: JsonValue?.fields,
    }));
  }, [subFieldsValue, JsonValue]);

  const handleSaveParameters = () => {
    let newObj = [];
    fieldsValue.forEach((fieldName, index) => {
      newObj = [...newObj, { [fieldName.name]: {} }];
      subFieldsValue.forEach((item) => {
        if (fieldName.name === item.fieldName) {
          if (item.isArray) {
            const fieldame = fieldName.name;
            const subFieldName = item.subFieldName;
            const nestedKey = item.nestedKey;
            if (!newObj[index][fieldame][subFieldName]) {
              newObj[index][fieldame] = { [item.subFieldName]: [] };
            }
            console.log(fieldame, nestedKey);
            if (fieldame === nestedKey) {
              newObj[index][fieldame][subFieldName].push(item.subFieldValue);
            }
            if (fieldame !== nestedKey && item.subFieldName === 'sub_fields') {
              const findnest = newObj[index][fieldame][subFieldName].find((item) => {
                return item[nestedKey];
              });
              if (!findnest) {
                newObj[index][fieldame][subFieldName].push({
                  [item.nestedKey]: { sub_fields: [] },
                });
                const findnest = newObj[index][fieldame][subFieldName].find((item) => {
                  return item[nestedKey];
                });
                findnest[item.nestedKey][subFieldName].push(item.subFieldValue);
              }
              if (findnest) {
                findnest[item.nestedKey][subFieldName].push(item.subFieldValue);
              }
            }
          } else {
            console.log(item, 'elseiff');
            if (item.fieldName !== item.nestedKey) {
              const testm = newObj[index][item.fieldName][item.subFieldName].find((itm) => itm[item.nestedKey]);
              console.log(testm);
              console.log(testm[item.nestedKey], 'Dasss');
              Object.assign(testm[item.nestedKey], item.subFieldValue);
            } else {
              console.log(
                (newObj[index][item.fieldName] = Object.assign(newObj[index][item.fieldName], item.subFieldValue))
              );
            }
          }
        }
      });
      dispatch(createJson({ fields: newObj }));
    });
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs
          TabIndicatorProps={{ style: { background: 'none' } }}
          value={value}
          onChange={handleChange}
          aria-label="basic tabs example"
        >
          <Tab label="Subfield" {...a11yProps(0)} />
          <Tab label="Filters" {...a11yProps(1)} />
          <Tab label="Others" {...a11yProps(2)} />
        </Tabs>
      </Box>
      <TabPanel value={value} index={0}>
        <SubFieldParameter selectedField={selectedField} />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <FiltersParameter parameterID={selectedField} />
      </TabPanel>
      <TabPanel value={value} index={2}>
        <OthersParameters parameterID={selectedField} />
      </TabPanel>
      <div className="flex-container">
        <Button color="tertiary" variant="outlined" onClick={() => handleSubFieldModal(false)}>
          Cancel
        </Button>
        <Button color="secondary" variant="outlined" onClick={() => setIsOpen(true)}>
          Add Fields
        </Button>
        <Button variant="contained" color="primary" onClick={() => handleSaveParameters()}>
          Save Parameters
        </Button>
      </div>
      <CustomModal
        showModal={isOpen}
        bodyComponent={<NestedSubFieldContainer handleNestedSubFieldModal={handleNestedSubFieldModal} />}
        className={'Modal nestedfields'}
      />
    </Box>
  );
}
