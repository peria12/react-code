import Button from '@mui/material/Button';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addOthers } from '../FieldsTab/fieldsSlice';
import OthersParametersTable from './OthersParametersTable';

const inlineFormStyles = {
  display: 'flex',
  gap: '8px',
};

const OthersParameters = ({ parameterID }) => {
  const dispatch = useDispatch();

  const initialState = {
    key: '',
    value: '',
  };
  const [keyValue, setKeyValue] = useState(initialState);

  const update = (event) => {
    const { name, value } = event.target;
    setKeyValue((prev) => {
      return { ...prev, [name]: value };
    });
  };

  const submitHandler = (event) => {
    event.preventDefault();
    setKeyValue(keyValue);
    dispatch(addOthers({ keyValue, parameterID }));
  };

  return (
    <>
      <form style={inlineFormStyles} onSubmit={submitHandler}>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>Key</Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 200 }}>
          <InputBase sx={{ ml: 1, flex: 1 }} name="key" onChange={update} inputProps={{ 'aria-label': 'Add key' }} />
        </Paper>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
          Value
        </Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 250 }}>
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            name="value"
            onChange={update}
            inputProps={{ 'aria-label': 'Add value' }}
          />
        </Paper>
        <Button color="secondary" variant="outlined" type="submit">
          Add Key Value
        </Button>
      </form>

      <OthersParametersTable />
    </>
  );
};

export default OthersParameters;
