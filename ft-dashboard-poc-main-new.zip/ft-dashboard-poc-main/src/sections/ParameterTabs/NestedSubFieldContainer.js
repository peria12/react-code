import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import { useState } from 'react';
import AddFieldComponent from '../../components/AddFieldComponent';
import TableComponent from '../../components/TableComponent';
import Iconify from '../../components/iconify';

const handleAddField = () => {};
const NestedSubFieldContainer = ({ handleNestedSubFieldModal }) => {
  const [isOpen, setIsOpen] = useState(false);

  const columns = [
    { field: 'name', headerName: 'Fields', flex: 0.5, editable: false, sortable: false },
    {
      field: 'parameters',
      headerName: 'Parameters',
      flex: 1,
      editable: false,
      sortable: false,
      renderCell: (params) => {
        const handleOpenParameters = () => {
          console.log(params, 'nested');
          setIsOpen(true);
        };
        return (
          <button
            style={{
              backgroundColor: '#E2F3F4',
              color: '#000000CC',
              cursor: 'pointer',
              textAlign: 'start',
              border: 'none',
              width: '100%',
              height: '45px',
            }}
            onClick={handleOpenParameters}
          >
            Parameters
          </button>
        );
      },
    },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation(); // don't select this row after clicking
          // <ConfirmationDialog fieldName={fieldName} rowID={params.id} />;
          // dispatch(removeFields(params.id));
          // console.log(params.id);
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <>
      <AddFieldComponent fieldName={[]} tableComponent={<TableComponent rows={[]} columns={columns} />} />
      <div className="flex-container">
        <Button color="tertiary" variant="outlined" onClick={() => handleNestedSubFieldModal(false)}>
          Cancel
        </Button>
        <Button variant="contained" color="primary" onClick={() => handleAddField()}>
          Next
        </Button>
      </div>
    </>
  );
};

export default NestedSubFieldContainer;
