import { Box, IconButton } from '@mui/material';
import CardContent from '@mui/material/CardContent';
import { DataGrid } from '@mui/x-data-grid';
import { useDispatch, useSelector } from 'react-redux';
import Iconify from '../../components/iconify';
import { removeOthers } from '../FieldsTab/fieldsSlice';
import TableNoData from '../../components/TableNoData';
import TableComponent from '../../components/TableComponent';

const OthersParametersTable = () => {
  const dispatch = useDispatch();

  const others = useSelector((state) => state.fields?.others);
  // console.log('others', others);

  const columns = [
    { field: 'key', headerName: 'Key', flex: 1, editable: false, sortable: false },
    { field: 'value', headerName: 'Values', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeOthers(params.id));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <TableComponent rows={others} columns={columns}/>
  );
};

export default OthersParametersTable;
