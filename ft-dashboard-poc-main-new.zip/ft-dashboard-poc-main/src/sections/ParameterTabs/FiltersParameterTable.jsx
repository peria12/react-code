import { IconButton } from '@mui/material';
import CardContent from '@mui/material/CardContent';
import { DataGrid } from '@mui/x-data-grid';
import { useDispatch, useSelector } from 'react-redux';
import TableNoData from '../../components/TableNoData';
import TableComponent from '../../components/TableComponent';
import Iconify from '../../components/iconify';
import { removeFilters } from '../FieldsTab/fieldsSlice';

const FiltersParameterTable = () => {
  const dispatch = useDispatch();
  const filters = useSelector((state) => state.fields?.filters);

  const columns = [
    { field: 'filterID', headerName: 'Filter IDs', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeFilters(params.id));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <TableComponent rows={filters} columns={columns}/>
  );
};

export default FiltersParameterTable;
