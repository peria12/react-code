import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Stepper from '@mui/material/Stepper';
import Typography from '@mui/material/Typography';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import AuthenticationMessage from '../../components/authentication-message';
import CopyrightText from '../../components/copyright-text';
import DatesContainer from '../DatesTabs';
import EntitiesContainer from '../EntitiesTabs';
import FieldsContainer from '../FieldsTab';

const steps = ['Fields', 'Entities', 'Dates'];

// function renderRow() {
//   <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
//     {[1, 2, 3].map((value) => (
//       <ListItem
//         key={value}
//         secondaryAction={<Iconify aria-label="list" icon={'gridicons:menus'} sx={{ color: 'pink' }} />}
//       >
//         <ListItemText primary={`Line item ${value}`} />
//       </ListItem>
//     ))}
//   </List>;
// }

export default function DALPlugin() {
  const navigate = useNavigate();

  const [activeStep, setActiveStep] = useState(0);
  const [currentScreen,setCurrentScreen]= useState("")
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    console.log(currentScreen,"CS")
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  useEffect(()=>{},[currentScreen])

  const handleCancel = () => {
    navigate('/');
  };

  // const fieldsData = useSelector(selectAllFields);

  // const fetchUsers = async () => {
  //   const response = await fetch('https://jsonplaceholder.typicode.com/users');
  //   const data = await response.json();
  //   dispatch(addFields(data));
  //   console.log('fieldsData', fieldsData);
  // };

  // useEffect(() => {
  //   fetchUsers();
  // }, []);

  return (
    <Box sx={{ width: '100%', marginTop: '80px' }}>
      <Stepper activeStep={activeStep} alternativeLabel>
        {steps.map((label, index) => {
          const stepProps = {};
          const labelProps = {};

          return (
            <Step key={label} {...stepProps}>
              <StepLabel {...labelProps}>{label}</StepLabel>
            </Step>
          );
        })}
      </Stepper>
      {activeStep === steps.length ? (
        <>
          <Card sx={{ minWidth: 275, minHeight: 300, margin: 2 }}>
            <CardContent>
              <Typography variant="body2">Fetching data...</Typography>
              <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
                <Box sx={{ flex: '1 1 auto' }} />
                {/* <Button onClick={handleReset}>Reset</Button> */}
              </Box>
            </CardContent>
          </Card>
        </>
      ) : (
        <>
          <Typography sx={{ my: 2 }}>
            <Card sx={{ width: '100%', minHeight: 420 }}>
              {activeStep === 0 && <FieldsContainer setCurrentScreen={setCurrentScreen}/>}
              {activeStep === 1 && <EntitiesContainer setCurrentScreen={setCurrentScreen}/>}
              {activeStep === 2 && <DatesContainer setCurrentScreen={setCurrentScreen}/>}
            </Card>
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
            <Button
              color="tertiary"
              variant="outlined"
              //  disabled={activeStep === 0}
              onClick={handleCancel}
            >
              Cancel
            </Button>
            <Box sx={{ flex: '1 1 auto' }} />
            {activeStep !==0 && (
              <Button color="secondary" variant="outlined" onClick={handleBack} sx={{ mr: 1 }}>
                Previous
              </Button>
            )}
            {activeStep === steps.length - 1 ?
            <Button variant="contained" color="primary">
               Fetch Data
            </Button>
                    :
            <Button variant="contained" color="primary" onClick={handleNext}>
              Next
            </Button>
            }
          </Box>
          <AuthenticationMessage />
          <CopyrightText />
        </>
      )}
    </Box>
  );
}
