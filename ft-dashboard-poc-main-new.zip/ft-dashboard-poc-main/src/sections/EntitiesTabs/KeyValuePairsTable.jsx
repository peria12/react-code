import { Box, IconButton } from '@mui/material';
import CardContent from '@mui/material/CardContent';
import { DataGrid } from '@mui/x-data-grid';
import { useDispatch, useSelector } from 'react-redux';
import Iconify from '../../components/iconify';
import { removeKeyValuePairs } from './entitiesSlice';
import TableNoData from '../../components/TableNoData';
import TableComponent from '../../components/TableComponent';

const KeyValuePairsTable = () => {
  const dispatch = useDispatch();

  const selectedEntityData = useSelector((state) => state.entities?.selectedEntityData);
  const filteredObjData = []
  function entityDataObjFormat(){
    selectedEntityData.forEach(item=>{
      if(typeof item === 'object'){
      const Obj = Object.entries(item)
      filteredObjData.push({
        id: Math.random() * 100,
        key: Obj[0][0],
        value: Obj[0][1],
      })
    }
    })
    return filteredObjData
  }
  const columns = [
    { field: 'key', headerName: 'Key', flex: 1, editable: false, sortable: false },
    { field: 'value', headerName: 'Values', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeKeyValuePairs(params.row));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <TableComponent rows={entityDataObjFormat()} columns={columns}/>
  );
};

export default KeyValuePairsTable;
