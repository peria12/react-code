import { Box, IconButton } from '@mui/material';
import { DataGrid, GridToolbarQuickFilter } from '@mui/x-data-grid';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import TableNoData from '../../components/TableNoData';
import TableComponent from '../../components/TableComponent';
import Iconify from '../../components/iconify';
import useLocalStorage from "../../hooks/useLocalStorage";
import { addSearchEntity, removeSearchEntity, updateSearchEntity } from './entitiesSlice';

function QuickSearchToolbar() {
  return (
    <Box sx={{ p: 0.5, pb: 0 }}>
      <GridToolbarQuickFilter />
    </Box>
  );
}

const SearchTab = () => {
  const [error, setError] = useState(false);

  const dispatch = useDispatch();

  const actualEntityData = useSelector((state) => state.entities?.actualEntitiesData);
  const selectedEntityData = useSelector((state) => state.entities?.selectedEntityData);
  const EntityData = useSelector((state) => state);
  const [jsonCreator, setJsonCreator] = useLocalStorage("createdJson", "")
  let filteredData = []
  function EntityDataFormat() {
    selectedEntityData.forEach(item => {
      if (typeof item !== 'object')
        filteredData = [...filteredData, { id: item, rowID: item }]
    })
    return filteredData
  }


  useEffect(() => {
    if (jsonCreator?.entities) {
      dispatch(updateSearchEntity(jsonCreator.entities));
    }
  }, [])
  useEffect(() => {
    setJsonCreator(prevState => ({
      ...prevState,
      entities: selectedEntityData
    }));
  }, [selectedEntityData])
  const columns = [
    { field: 'entity_id', headerName: 'Entities', width: 250, editable: false, sortable: false },
    { field: 'entity_name', headerName: 'Description', flex: 1, editable: false, sortable: false },
  ];
  const selectedEntityColumns = [
    { field: 'rowID', headerName: 'Entities', flex: 1, editable: false, sortable: false },
    { field: 'entity_name', headerName: 'Values', flex: 1, editable: false, sortable: false },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeSearchEntity(params.id));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  const handleOnRowDoubleClick = (rowData, id) => {
    if (!selectedEntityData.includes(id)) {
      setError(false)
      dispatch(addSearchEntity(id));
      EntityDataFormat()
    } else {
      setError(true)
    }
    console.log(rowData);
  };

  return (
    <>
      <Box sx={{ padding: 0, height: 350, width: '100%' }}>
        {error && <small className='error'>Entities Already Selected</small>}

        <DataGrid
          rows={actualEntityData}
          columns={columns}
          rowHeight={48}
          initialState={{
            pagination: {
              paginationModel: {
                pageSize: 5,
              },
            },
          }}
          sx={{
            '&.MuiDataGrid-root .MuiDataGrid-columnHeader:focus, &.MuiDataGrid-root .MuiDataGrid-cell:focus-within': {
              outline: 'none',
            },
            overflowX: 'hidden',
          }}
          pageSizeOptions={[5]}
          disableRowSelectionOnClick
          disableColumnMenu
          slots={{
            noRowsOverlay: TableNoData,
            toolbar: QuickSearchToolbar,
          }}
          localeText={{
            toolbarQuickFilterPlaceholder: 'Search Entities',
          }}
          onRowDoubleClick={(param) => handleOnRowDoubleClick(param.row, param.id)}
        />
      </Box>
      <Box sx={{ padding: '24px 0px', height: 250, width: '100%' }}>
      <TableComponent rows={EntityDataFormat()} columns={selectedEntityColumns} tableHeight={250}/>
      </Box>
    </>
  );
};

export default SearchTab;
