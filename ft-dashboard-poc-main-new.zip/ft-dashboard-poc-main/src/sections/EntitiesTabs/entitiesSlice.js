import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  actualEntitiesData: [], // addActualEntitiesData => Entities list from the API
  selectedEntityData: [], // not in use right now || TODO ||
  entitiesList: [],
  keyValuePairs: [],
  entitiesKeyList: [],
};

const entitiesSlice = createSlice({
  name: 'entities',
  initialState,
  reducers: {
    addActualEntitiesData: (state, { payload }) => {
      state.actualEntitiesData = payload;
    },
    addSearchEntity: (state, { payload }) => {
      state.selectedEntityData.push(payload);
      console.log('Add Payload', payload);
    },
    updateSearchEntity: (state, { payload }) => {
      state.selectedEntityData = payload
    },
    removeSearchEntity: (state, { payload }) => {
      state.selectedEntityData = state.selectedEntityData.filter((entity) => entity !== payload);
    },
    addEntitiesKeyList: (state, { payload }) => {
      state.entitiesKeyList = payload;
    },
    addKeyValuePairs: (state, { payload }) => {
      const { entitiesList, keyValuePairs } = state;
      const keyValuePairsData = {
        id: Math.random() * 100,
        key: payload.keyValue.key,
        value: payload.keyValue.value,
      };
      state.keyValuePairs.push(keyValuePairsData);
    },
    removeKeyValuePairs: (state, { payload }) => {
      state.selectedEntityData = state.selectedEntityData.filter((item) => {
        let keep = true;
        if (typeof item === "object") {
          const val = Object.entries(item);
          keep = val[0][0] !== payload.key || val[0][1] !== payload.value;
        }
        return keep;
      })
    },
  },
});

// export actions
export default entitiesSlice.reducer;
export const {
  addActualEntitiesData,
  addSearchEntity,
  updateSearchEntity,
  addEntitiesKeyList,
  removeSearchEntity,
  addKeyValuePairs,
  removeKeyValuePairs,
} = entitiesSlice.actions;
