import Button from '@mui/material/Button';
import CardContent from '@mui/material/CardContent';
import IconButton from '@mui/material/IconButton';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Iconify from '../../components/iconify';

const inlineFormStyles = {
  display: 'flex',
  gap: '8px',
};

const tableHead = {
  '& .MuiTableCell-head': {
    color: '#000000CC',
    backgroundColor: '#FFF',
  },
};
const tableStyle = {
  '& .MuiTableHead-root': {
    borderBottom: '3px solid #000000CC',
  },
};

const SelectFromExcelTab = () => {
  const navigate = useNavigate();

  const [activeStep, setActiveStep] = useState(0);
  const [skipped, setSkipped] = useState(new Set());
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [openMenu, setOpenMenu] = useState(false);
  const [scroll, setScroll] = useState('paper');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const isStepOptional = (step) => {
    return step === 1;
  };

  const isStepSkipped = (step) => {
    return skipped.has(step);
  };

  const handleNext = () => {
    let newSkipped = skipped;
    if (isStepSkipped(activeStep)) {
      newSkipped = new Set(newSkipped.values());
      newSkipped.delete(activeStep);
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped(newSkipped);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleCancel = () => {
    navigate('/');
    // alert('cancelled!');
  };

  const handleOpenSuggestion = () => {
    setOpenMenu(true);
  };

  const handleListItemClick = (event, index) => {
    setSelectedIndex(index);
  };

  const handleSkip = () => {
    if (!isStepOptional(activeStep)) {
      // You probably want to guard against something like this,
      // it should never occur unless someone's actively trying to break something.
      throw new Error("You can't skip a step that isn't optional.");
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped((prevSkipped) => {
      const newSkipped = new Set(prevSkipped.values());
      newSkipped.add(activeStep);
      return newSkipped;
    });
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const handleClickOpen = (scrollType) => () => {
    setOpenMenu(true);
    setScroll(scrollType);
  };

  const handleClose = () => {
    setOpenMenu(false);
  };

  const handleOpenParameters = () => {
    navigate('/parameter-subfield');
  };

  const descriptionElementRef = useRef(null);
  useEffect(() => {
    if (openMenu) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [openMenu]);

  return (
    <CardContent sx={{ padding: '0px' }}>
      <div style={inlineFormStyles}>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
          ID Type
        </Typography>
        <Paper component="form" sx={{ display: 'flex', marginRight: '16px', alignItems: 'center', width: 270 }}>
          <InputBase sx={{ ml: 1, flex: 1 }} placeholder="" inputProps={{ 'aria-label': 'Add Sub Fields' }} />
        </Paper>
        <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
          ID Date
        </Typography>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DemoContainer components={['DatePicker']}>
            <DatePicker sx={{ width: '150px', overflow: 'hidden' }} />
          </DemoContainer>
        </LocalizationProvider>
        {/* <Button variant="outlined" color="secondary" startIcon={<Iconify icon={'file-icons:microsoft-excel'} />}>
            Select
          </Button> */}
      </div>
    </CardContent>
  );
};

export default SelectFromExcelTab;
