import { FormGroup } from '@mui/material';
import Button from '@mui/material/Button';
import InputBase from '@mui/material/InputBase';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import useLocalStorage from '../../hooks/useLocalStorage';
import KeyValuePairsTable from './KeyValuePairsTable';
import { addSearchEntity, addKeyValuePairs } from './entitiesSlice';

const inlineFormStyles = {
  display: 'flex',
  gap: '8px',
  justifyContent: 'space-between',
};

const KeyValuePairsTab = ({ parameterID }) => {
  const dispatch = useDispatch();
  const [jsonCreator, setJsonCreator] = useLocalStorage('createdJson', '');
  const [selectedDate, setSelectedDate] = useState(null);
  const selectedEntityData = useSelector((state) => state.entities?.selectedEntityData);

  const initialState = {
    key: '',
    value: '',
  };
  const [keyValue, setKeyValue] = useState(initialState);

  const update = (event) => {
    const { name, value } = event.target;
    setKeyValue((prev) => {
      return { ...prev, [name]: value };
    });
  };

  const submitHandler = (event) => {
    console.log(keyValue, 'Dasd');
    event.preventDefault();
    setKeyValue(keyValue);
    dispatch(addKeyValuePairs({ keyValue, parameterID }));
    console.log({ [keyValue.key]: keyValue.value }, 'keyvalue');
    dispatch(addSearchEntity({ [keyValue.key]: keyValue.value }));
  };
  useEffect(() => {
    setJsonCreator((prevState) => ({
      ...prevState,
      entities: selectedEntityData,
    }));
  }, [selectedEntityData]);
  return (
    <>
      <form style={inlineFormStyles} onSubmit={submitHandler}>
        <FormGroup sx={{ flexDirection: 'row' }}>
          <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
            Key
          </Typography>
          <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 200 }}>
            <InputBase sx={{ ml: 1, flex: 1 }} name="key" onChange={update} inputProps={{ 'aria-label': 'Add key' }} />
          </Paper>
          <Typography sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', alignItems: 'center' }}>
            Value
          </Typography>
          <Paper component="form" sx={{ display: 'flex', marginRight: '16px', width: 250 }}>
            <InputBase
              sx={{ ml: 1, flex: 1 }}
              name="value"
              onChange={update}
              inputProps={{ 'aria-label': 'Add value' }}
            />
          </Paper>
          <Button variant="contained" color="primary" type="submit">
            Add Key & Value
          </Button>
        </FormGroup>
        <FormGroup sx={{ flexDirection: 'row' }}>
          <Typography sx={{ color: '#8E8D8D', fontSize: '15px', marginRight: '16px' }}>ID Date</Typography>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer components={['DatePicker']}>
              <DatePicker
                disableFuture
                format="YYYY-MM-DD"
                value={selectedDate}
                onChange={(newDateValue) => {
                  setSelectedDate(newDateValue);
                  // console.log('selectedDate');
                }}
                sx={{ width: '150px', overflow: 'hidden' }}
              />
            </DemoContainer>
          </LocalizationProvider>
        </FormGroup>
      </form>

      <KeyValuePairsTable />
    </>
  );
};

export default KeyValuePairsTab;
