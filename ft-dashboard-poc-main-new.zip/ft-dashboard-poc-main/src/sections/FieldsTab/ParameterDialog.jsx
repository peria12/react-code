import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import InputBase from '@mui/material/InputBase';
import InputLabel from '@mui/material/InputLabel';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Paper from '@mui/material/Paper';
import fieldName from '../../_mock/fieldsname';
import AuthenticationMessage from '../../components/authentication-message';
import ParametersContainer from '../ParameterTabs/ParametersContainer';
// import { useEffect } from 'react';

const dialogContainer = {
  '& .MuiDialog-paper': {
    width: '100%',
    maxWidth: '90%',
    height: '80%',
  },
  '& .MuiDialogContent-root': {
    border: 'none',
    padding: '6px 24px 16px',
  },
  '& .MuiDialogActions-root': {
    padding: '30px 24px 24px',
    display: 'flex',
    justifyContent: 'space-between',
  },
};

const ParameterDialog = (props) => {
  const { onClose, selectedValue, open } = props;

  const handleClose = () => {
    onClose(selectedValue);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="scroll-dialog-title"
      aria-describedby="scroll-dialog-description"
      sx={dialogContainer}
    >
      <ParametersContainer />
    </Dialog>
  );
};

export default ParameterDialog;
