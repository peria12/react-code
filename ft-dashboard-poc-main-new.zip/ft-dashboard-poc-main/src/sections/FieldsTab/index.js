import FieldsContainer from './FieldsContainer';

export default FieldsContainer;
