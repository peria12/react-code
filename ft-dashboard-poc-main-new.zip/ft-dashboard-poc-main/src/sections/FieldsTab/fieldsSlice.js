import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  fieldsNameList: [],
  subFieldsValue: [],
  filters: [],
  others: [],
};

const fieldsSlice = createSlice({
  name: 'fields',
  initialState,
  reducers: {
    addFields: (state, { payload }) => {
      state.fieldsNameList.push(payload);
    },
    removeFields: (state, { payload }) => {
      state.fieldsNameList = state.fieldsNameList.filter((fieldName) => fieldName.id !== payload);
    },
    addSubField: (state, { payload }) => {
      state.subFieldsValue.push(payload)
    },
    removeSubField: (state, { payload }) => {
      state.subFieldsValue = state.subFieldsValue.filter((subFieldName) => subFieldName.id !== payload);
    },
    addFilters: (state, { payload }) => {
      const { fieldsNameList, filters } = state;
      const filtersData = {
        id: payload.parameterID,
        filterIDType: payload.filterIDValue.filterIDType,
        filterID: payload.filterIDValue.filterID,
        field: payload.parameterID
      };
      fieldsNameList.filter(getUniqueID);
      function getUniqueID(fieldName) {
        if (fieldName.id === payload.parameterID) {
          // console.log('Its same');
          state.filters.push(filtersData);
        }
        return filters;
      }
    },
    removeFilters: (state, { payload }) => {
      state.filters = state.filters.filter((filterName) => filterName.id !== payload);
    },
    addOthers: (state, { payload }) => {
      const { fieldsNameList, others } = state;
      const othersData = {
        id: Math.random() * 100,
        key: payload.keyValue.key,
        value: payload.keyValue.value,
      };
      fieldsNameList.filter(getUniqueID);
      function getUniqueID(fieldName) {
        if (fieldName.id === payload.parameterID) {
          console.log('Its same');
          state.others.push(othersData);
        }
        return others;
      }
    },
    removeOthers: (state, { payload }) => {
      state.others = state.others.filter((otherName) => otherName.id !== payload);
      console.log('deleted others item');
    },
  },
});

export default fieldsSlice.reducer;
// export actions
export const {
  addFields,
  removeFields,
  addSubField,
  removeSubField,
  addFilters,
  removeFilters,
  addOthers,
  removeOthers,
} = fieldsSlice.actions;

// console.log(fieldsSlice.actions);

// export data
export const getAllFields = (state) => state.fields?.fieldsNameList;
export const getSubFieldValue = (state) => state.fields?.subFieldsValue;
// export const getAllFilters = (state) => state.fields?.fieldsNameList.fil;
