import IconButton from '@mui/material/IconButton';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AddFieldComponent from '../../components/AddFieldComponent';
import CustomModal from '../../components/CustomModal';
import TableComponent from '../../components/TableComponent';
import Iconify from '../../components/iconify';
import ParametersContainer from '../ParameterTabs/ParametersContainer';
import { addFields, getAllFields, removeFields } from './fieldsSlice';
import fieldName  from '../../_mock/fieldsname';

const FieldsContainer = ({setCurrentScreen}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [error, setError] = useState(false);
  const [searchFieldValue, setSearchFieldValue] = useState('');
  const [selectedField, setSelectedField] = useState('');
  const dispatch = useDispatch();
  const rows = useSelector(getAllFields);

  const handleSearchFieldOnChange = (event) => {
    setSearchFieldValue(event.target.value);
  };

  const onSearchField = (searchTerm) => {
    setSearchFieldValue(searchTerm);
  };
  const handleSubFieldModal = () => {
    setIsOpen(false);
  };
  useEffect(()=>{
    setCurrentScreen("FieldScreen")
  },[])
  const handleAddField = () => {
    const isPresent = rows.some((item) => item.name === searchFieldValue);
    if (!isPresent && searchFieldValue !== '') {
      setError(false);
      dispatch(
        addFields({
          id: searchFieldValue,
          name: searchFieldValue,
        })
      );
    } else {
      setError(true);
    }
  };

  const columns = [
    { field: 'name', headerName: 'Fields', flex: 0.5, editable: false, sortable: false },
    {
      field: 'parameters',
      headerName: 'Parameters',
      flex: 1,
      editable: false,
      sortable: false,
      renderCell: (params) => {
        const handleOpenParameters = () => {
          setSelectedField(params.id);
          setIsOpen(true);
        };
        return (
          <button
            style={{
              backgroundColor: '#E2F3F4',
              color: '#000000CC',
              cursor: 'pointer',
              textAlign: 'start',
              border: 'none',
              width: '100%',
              height: '45px',
            }}
            onClick={handleOpenParameters}
          >
            Parameters
          </button>
        );
      },
    },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      width: 150,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          dispatch(removeFields(params.id));
        };

        return (
          <IconButton
            sx={{
              height: '18px',
              padding: '0px',
              cursor: 'pointer',
              color: '#585858',
            }}
            onClick={onClick}
          >
            <Iconify icon={'iconoir:trash'} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <>
      <AddFieldComponent
        fieldName={fieldName.sort()}
        handleSearchFieldOnChange={handleSearchFieldOnChange}
        onSearchField={onSearchField}
        searchFieldValue={searchFieldValue}
        handleAddField={handleAddField}
        error={error}
        tableComponent={<TableComponent rows={rows} columns={columns} />}
      />
      <CustomModal
        showModal={isOpen}
        bodyComponent={<ParametersContainer selectedField={selectedField} handleSubFieldModal={handleSubFieldModal} />}
        className={'Modal'}
        closeModal={()=>{setIsOpen(false)}}
      />
    </>
  );
};

export default FieldsContainer;
