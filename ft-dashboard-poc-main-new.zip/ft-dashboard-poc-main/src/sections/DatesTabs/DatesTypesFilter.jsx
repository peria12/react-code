import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Box, FormGroup, InputBase, InputLabel, MenuItem, Paper, Select } from '@mui/material';
import { selectedDatesType } from './datesSlice';

const DatesTypesFilter = () => {
  const [isDisabled, setIsDisabled] = useState(false);
  const datesType = useSelector(selectedDatesType);

  useEffect(() => {
    if (datesType !== 'series') {
      setIsDisabled(true);
    } else {
      setIsDisabled(false);
    }
  }, [datesType]);

  return (
    <Box sx={{ flex: 1, py: 1 }}>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="label">Frequency</InputLabel>
        <Select sx={{ width: '210px' }} labelId="label" id="frequency" value="weekly" disabled={isDisabled}>
          <MenuItem value="daily">Daily</MenuItem>
          <MenuItem value="weekly">Weekly</MenuItem>
          <MenuItem value="monthly">Monthly</MenuItem>
          <MenuItem value="quarterly">Quarterly</MenuItem>
          <MenuItem value="yearly">Yearly</MenuItem>
        </Select>
      </FormGroup>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="fillMissing">Fill Missing</InputLabel>
        <Select sx={{ width: '210px' }} labelId="label" id="select" value="last" disabled={isDisabled}>
          <MenuItem value="no">No</MenuItem>
          <MenuItem value="last">Last</MenuItem>
        </Select>
      </FormGroup>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="label">Align</InputLabel>
        <Select sx={{ width: '210px' }} labelId="label" id="align" value="end" disabled={isDisabled}>
          <MenuItem value="start">Start</MenuItem>
          <MenuItem value="end">End</MenuItem>
        </Select>
      </FormGroup>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="label">Interval</InputLabel>
        <Paper component="form">
          <InputBase inputProps={{ 'aria-label': 'Add interval' }} disabled={isDisabled} />
        </Paper>
      </FormGroup>
      <FormGroup sx={{ flexDirection: 'row', marginBottom: '12px' }}>
        <InputLabel id="label">Look Back</InputLabel>
        <Paper component="form">
          <InputBase inputProps={{ 'aria-label': 'Add look back' }} disabled={isDisabled} />
        </Paper>
      </FormGroup>
    </Box>
  );
};

export default DatesTypesFilter;
