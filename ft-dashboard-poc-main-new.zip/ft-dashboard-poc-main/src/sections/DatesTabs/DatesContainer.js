import { Box, FormControl, FormGroup } from '@mui/material';
import Button from '@mui/material/Button';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Iconify from '../../components/iconify';
import useLocalStorage from '../../hooks/useLocalStorage';
import DatesTypes from './DatesTypes';
import DatesTypesFilter from './DatesTypesFilter';
import SelectedDatesTable from './SelectedDatesTable';
import { addSelectedDate, selectedDates, updateSelectedDate } from './datesSlice';

const DatesContainer = () => {
  const dispatch = useDispatch();
  const [jsonCreator, setJsonCreator] = useLocalStorage('createdJson', '');
  const [selectedDate, setSelectedDate] = useState(null);
  const [error, setError] = useState(false);
  const selectedDatesVal = useSelector(selectedDates);
  const handleAddDate = () => {
    const formatDate = new Date(selectedDate.$d.getTime() - selectedDate.$d.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 10);
    if (!selectedDatesVal.includes(formatDate)) {
      setError(false);
      dispatch(addSelectedDate(formatDate));
    } else {
      setError(true);
    }
  };

  useEffect(() => {
    if (jsonCreator?.dates) {
      dispatch(updateSelectedDate(jsonCreator.dates));
    }
  }, []);
  useEffect(() => {
    setJsonCreator((prevState) => ({
      ...prevState,
      dates: selectedDatesVal,
    }));
  }, [selectedDatesVal]);

  return (
    <CardContent>
      <Box
        sx={{
          borderBottom: 1,
          borderColor: 'divider',
          display: 'flex',
          justifyContent: 'space-between',
          paddingBottom: '12px',
        }}
      >
        <FormGroup sx={{ flexDirection: 'row' }}>
          <FormControl sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
            <Typography sx={{ color: '#8E8D8D', fontSize: '15px', marginRight: '16px', alignItems: 'center' }}>
              Date
            </Typography>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DemoContainer components={['DatePicker']}>
                <DatePicker
                  disableFuture
                  format="YYYY-MM-DD"
                  value={selectedDate}
                  onChange={(newDateValue) => {
                    setSelectedDate(newDateValue);
                    // console.log(selectedDate);
                  }}
                  sx={{ width: '150px', overflow: 'hidden' }}
                />
              </DemoContainer>
            </LocalizationProvider>
          </FormControl>
          <FormControl sx={{ display: 'flex', marginLeft: '16px' }}>
            <Button variant="outlined" color="secondary" onClick={handleAddDate}>
              Add Dates
            </Button>
          </FormControl>
          {error && <small className="error"> Date Already Added</small>}
        </FormGroup>
        <FormGroup sx={{ flexDirection: 'row' }}>
          <DatesTypes />
          <Button
            sx={{ marginLeft: '16px' }}
            variant="outlined"
            color="secondary"
            startIcon={<Iconify icon={'file-icons:microsoft-excel'} />}
          >
            Select
          </Button>
        </FormGroup>
      </Box>

      <Box sx={{ display: 'flex' }}>
        <SelectedDatesTable />
        <DatesTypesFilter />
      </Box>
    </CardContent>
  );
};

export default DatesContainer;
