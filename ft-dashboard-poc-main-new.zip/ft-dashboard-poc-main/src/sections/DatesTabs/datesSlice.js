import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  selectedDatesType: 'snapshots',
  selectedDates: []
};

const datesSlice = createSlice({
  name: 'dates',
  initialState,
  reducers: {
    addSelectedDatesTypes: (state, { payload }) => {
      state.selectedDatesType = payload;
    },
    addSelectedDate: (state, { payload }) => {
      state.selectedDates.push(payload);
      console.log('Add Payload', payload);
    },
    updateSelectedDate: (state, { payload }) => {
      state.selectedDates = payload
    },
    removeSelectedDate: (state, { payload }) => {
      state.selectedDates = state.selectedDates.filter((entity) => entity !== payload);
    },
  },
});

export default datesSlice.reducer;
export const { addSelectedDatesTypes, addSelectedDate, updateSelectedDate, removeSelectedDate } = datesSlice.actions;

// export data
export const selectedDatesType = (state) => state.dates?.selectedDatesType;
export const selectedDates = (state) => state.dates?.selectedDates;