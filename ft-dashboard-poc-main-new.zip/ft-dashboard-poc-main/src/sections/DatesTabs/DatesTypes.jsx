import { useState } from 'react';
import { ToggleButton, ToggleButtonGroup, Typography } from '@mui/material';
import { useDispatch } from 'react-redux';
import { addSelectedDatesTypes } from './datesSlice';

const DatesTypes = () => {
  const dispatch = useDispatch();
  const [datesTypes, setDatesTypes] = useState('snapshots');

  const handleDatesType = (event, newDateType) => {
    setDatesTypes(newDateType);
    dispatch(addSelectedDatesTypes(newDateType));
  };

  return (
    <>
      <Typography
        sx={{ color: '#8E8D8D', fontSize: '15px', display: 'flex', marginRight: '16px', alignItems: 'center' }}
      >
        Date Type
      </Typography>
      <ToggleButtonGroup
        color="secondary"
        value={datesTypes}
        exclusive
        onChange={handleDatesType}
        aria-label="text alignment"
      >
        <ToggleButton value="series" aria-label="Series">
          Series
        </ToggleButton>
        <ToggleButton value="snapshots" aria-label="Snapshots">
          Snapshots
        </ToggleButton>
        <ToggleButton value="range" aria-label="Range">
          Range
        </ToggleButton>
      </ToggleButtonGroup>
    </>
  );
};

export default DatesTypes;
