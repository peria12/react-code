// ----------------------------------------------------------------------

export default function Table(theme) {
  return {
    MuiTableCell: {
      styleOverrides: {
        head: {
          color: theme.palette.text.secondary,
          backgroundColor: theme.palette.background.neutral,
        },
      },
    },
    MuiDataGrid: {
      styleOverrides: {
        root: {
          border: 'none',
        },
        columnHeader: {
          borderBottom: '2px solid #585858',
        },
        toolbarQuickFilter: {
          margin: '0',
        },
        MuiInputBase: {
          MuiSvgIcon: { display: 'none' },
        },
      },
    },
  };
}
