export default function Step(theme) {
  return {
    MuiStep: {
      styleOverrides: {
        root: {
          color: theme.palette.primary.main,
        },
      },
    },
  };
}
