import { useState } from 'react';
// @mui
import { IconButton } from '@mui/material';
import Iconify from '../../../components/iconify';

export default function Analytics() {
  const [open, setOpen] = useState(null);

  const handleOpen = (event) => {
    console.log('hello');
  };

  const handleClose = () => {
    setOpen(null);
  };

  return (
    <>
      <IconButton color={open ? 'primary' : 'default'} onClick={handleOpen} sx={{ width: 40, height: 40 }}>
        <Iconify icon="majesticons:analytics" />
      </IconButton>
    </>
  );
}
