
<!-- Fields Step -->

1. Get list of fields name from API (login time only fetch the list of data) 
2. Search fields in search box
3. upon clicking the 'Add Field Button' dispatch an Action named "storeFieldName()" add the data in the table 
4. for each row in the table we should have 'parameters buttons' and 'delete' actions
5. for each parameters sections => 'subfield, filters, others'


6. Fetch Feilds List => 2 places
7. 